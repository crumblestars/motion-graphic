# Blumenpyramide V4 — Spooky Floral

Révision de la V3 : plus de typographie cinétique et de motion design 2D, saisie de « Blumenpyramide » dans une barre de recherche, clic et rebond, zoom de sortie, bandes typographiques, lettres assemblées par masques, orbites et lune, tracés botaniques, résultat de recherche puis logo floral fourni dans la conversation.

Le tempo passe de 140 à **119 BPM**, soit exactement 15 % de moins. Les 70 beats donnent **35,3 secondes**, 2118 images à 60 images/seconde. Le master est en 1080 × 1920 ; la copie légère en 720 × 1280. La séquence de marque finale occupe environ 3,5 secondes, dont les deux dernières avec l'appel à commander.

## Sources modifiables

- `src/index.tsx` : les vingt séquences, leurs textes, la composition et les dessins SVG.
- `src/gsap-motion.json` : mouvements GSAP prééchantillonnés à 60 images/seconde.
- `research/bake-gsap.mjs` : chorégraphie GSAP de la recherche et de la carte résultat. Exécuter ce script après modification des courbes.
- `public/assets` : sept clips de fleurs préparés, logo, polices et musique originale avec bruitages de recherche.
- `research/music-v4.py` : création de la musique originale ; nécessite Python, NumPy et SciPy uniquement pour la régénérer.
- `MEDIA-CREDITS.md` et `licenses` : sources et crédits des médias et bibliothèques.

Les mouvements GSAP sont échantillonnés pour que chaque image reste déterministe dans Remotion, y compris lors d'un déplacement direct dans la timeline. Le film utilise Remotion 4.0.536, ses transitions et deux transitions crosswarp issues de GL Transitions. La révélation par masques de caractères est adaptée de remotion-scenes, sous licence MIT.

Prérequis vérifiés : Node 24.19.0, FFmpeg 7.1.5, Chromium 154.0.8037.57 sous Linux. Installer avec `npm ci`, vérifier avec `npm run check`, lancer l'éditeur avec `npm run studio` et rendre avec `npm run render`. Le script de rendu utilise `/usr/bin/chromium` et le WebGL logiciel `swangle`. Les transitions WebGL requièrent CanvasDrawElement, activé par Remotion dans son navigateur de rendu. Les autres transitions et les dessins 2D utilisent les transformations et SVG ordinaires.

Images de contrôle : `npm run still`. Préparation des copies, validation et storyboard : `python research/post-render.py`. Le lecteur HyperFrames de livraison est `index.html`, avec le MP4 final et sa piste audio intégrée. Contrôle : `npm run check:final` avec `HYPERFRAMES_BROWSER_PATH=/usr/bin/chromium`.

Les clips et la musique sont inclus : aucune régénération n'est nécessaire pour modifier les textes ou rendre le film. Les sources sont un projet Remotion ; aucun fichier After Effects `.aep` natif n'est fourni.

## Vérification et limites

Le contrôle de livraison vérifie la définition des deux versions, leur durée, leurs 2118 images à 60 images/seconde, H.264 et AAC stéréo, puis les décode intégralement avec FFmpeg. `deliverables/VALIDATION.json` conserve les métadonnées et empreintes SHA-256. Le storyboard est extrait du film livré.

Les vrais plans de fleurs sont issus de séquences génériques Creative Commons créditées ; ils ne représentent pas un catalogue commercial vérifié de Blumenpyramide. Leur source est en 1280 × 720 : le master 1080p améliore la netteté du texte et des éléments 2D, sans ajouter de détails à la vidéo florale d'origine. Aucun prix, délai ni stock n'est inventé. Le crédit complet des contributeurs doit accompagner une publication.

La licence Remotion incluse doit être consultée pour l'usage de son logiciel, notamment selon la taille de l'organisation. GSAP relève de sa licence standard ; il n'est pas présenté comme une dépendance MIT. Swishy, Pexels et Mixkit étaient inaccessibles lors des recherches de la V3 et aucun média de ces sites n'est utilisé ici.
