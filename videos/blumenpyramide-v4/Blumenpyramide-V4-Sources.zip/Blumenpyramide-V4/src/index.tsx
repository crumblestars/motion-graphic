import React,{useEffect,useState} from 'react';
import {AbsoluteFill,Audio,Composition,Img,OffthreadVideo,registerRoot,staticFile,useCurrentFrame,useVideoConfig,interpolate,spring,delayRender,continueRender,Easing} from 'remotion';
import {TransitionSeries,linearTiming} from '@remotion/transitions';
import type {TransitionPresentationComponentProps} from '@remotion/transitions';
import {slide} from '@remotion/transitions/slide';
import {wipe} from '@remotion/transitions/wipe';
import {crosswarp} from '@remotion/transitions/crosswarp';
import motion from './gsap-motion.json';

export const FPS=60,BPM=119,DURATION=2118;
export const at=(beat:number)=>Math.round(beat*FPS*60/BPM);
const C={black:'#090806',green:'#042f20',cream:'#f8efd9',orange:'#f16c2e',wine:'#6a142a',gold:'#dcb66c'};
const clamp={extrapolateLeft:'clamp',extrapolateRight:'clamp'} as const;
const fontCSS=`@font-face{font-family:Anton;src:url('${staticFile('assets/Anton-Regular.ttf')}')}@font-face{font-family:Quiet;src:url('${staticFile('assets/sans.otf')}')}@font-face{font-family:Atelier;src:url('${staticFile('assets/serif.otf')}')}*{box-sizing:border-box}`;
type Shot={start:number;end:number;kind:string;clip?:string;words?:string[];size?:number;anchor?:'top'|'center'|'bottom';tone?:string;kicker?:string;transition:'zoom'|'warp'|'wipe'|'slide'|'push';offset?:number;mode?:'rise'|'split'|'wave'|'stretch'};
export const shots:Shot[]=[
 {start:0,end:6,kind:'search',transition:'zoom'},
 {start:6,end:10,kind:'macro',clip:'red',words:['HERBST','ZAUBER.'],size:235,anchor:'center',kicker:'BLUMENPYRAMIDE',mode:'split',offset:.2,transition:'wipe'},
 {start:10,end:12,kind:'shutter',words:['DUNKEL.'],size:260,tone:'dark',transition:'slide'},
 {start:12,end:14,kind:'type',words:['EDEL.'],size:335,tone:'cream',mode:'wave',transition:'wipe'},
 {start:14,end:18,kind:'bloom',clip:'peach',words:['VOLLER','LEBEN.'],size:225,anchor:'bottom',mode:'stretch',transition:'push'},
 {start:18,end:20,kind:'ribbon',words:['FLORAL.'],tone:'cream',transition:'slide'},
 {start:20,end:24,kind:'macro',clip:'garden',words:['ECHT','MAGISCH.'],size:220,anchor:'bottom',mode:'split',transition:'wipe'},
 {start:24,end:28,kind:'date',transition:'warp'},
 {start:28,end:32,kind:'haunted',transition:'push'},
 {start:32,end:36,kind:'botanical',words:['IN VOLLER','BLÜTE.'],size:205,anchor:'center',mode:'wave',transition:'wipe'},
 {start:36,end:38,kind:'shutter',words:['FÜR DICH.'],size:225,tone:'orange',transition:'slide'},
 {start:38,end:42,kind:'bloom',clip:'peach',words:['ZUM','VERSCHENKEN.'],size:158,anchor:'top',mode:'split',offset:.1,transition:'push'},
 {start:42,end:44,kind:'ribbon',words:['MIT LIEBE.'],tone:'dark',transition:'wipe'},
 {start:44,end:48,kind:'split',clip:'golden',words:['FÜR DEIN','ZUHAUSE.'],size:185,anchor:'top',kicker:'DER HERBST ZIEHT EIN',transition:'slide'},
 {start:48,end:52,kind:'cutout',clip:'pink',transition:'warp'},
 {start:52,end:56,kind:'triptych',words:['UNSERE','HERBSTKREATIONEN.'],size:110,anchor:'top',kicker:'ENTDECKEN SIE',transition:'push'},
 {start:56,end:60,kind:'macro',clip:'golden',words:['JETZT','ENTDECKEN.'],size:200,anchor:'center',mode:'stretch',offset:.3,transition:'wipe'},
 {start:60,end:63,kind:'result',transition:'push'},
 {start:63,end:66,kind:'logo',transition:'push'},
 {start:66,end:70,kind:'final',transition:'push'},
];
export const transitionFrames=(i:number)=>shots[i].transition==='zoom'?16:shots[i].transition==='warp'?14:16;

const Atmosphere:React.FC<{forest?:boolean}>=({forest=false})=>{
 const f=useCurrentFrame(),{fps}=useVideoConfig();
 return <AbsoluteFill style={{background:forest?C.green:C.black,overflow:'hidden'}}>
  <AbsoluteFill style={{background:`radial-gradient(ellipse at ${24+Math.sin(f/fps*.35)*5}% 28%, #6a142a55 0%, transparent 55%),radial-gradient(ellipse at 80% 85%, #064b3266 0%, transparent 60%)`}}/>
  <AbsoluteFill style={{background:'radial-gradient(ellipse at center,transparent 25%,#00000099 100%)'}}/>
 </AbsoluteFill>;
};
const Moon:React.FC<{x?:number;y?:number;size?:number;opacity?:number}>=({x=830,y=180,size=140,opacity=.85})=><svg width={size} height={size} viewBox="0 0 160 160" style={{position:'absolute',left:x,top:y,opacity}}><path d="M110 12 A66 66 0 1 0 144 111 A63 63 0 0 1 110 12Z" fill={C.gold}/><circle cx="80" cy="80" r="76" fill="none" stroke={C.gold} strokeWidth=".6" opacity=".4"/></svg>;
const petalOutline=()=>{
 let d='';for(let j=0;j<=160;j++){const a=j/160*Math.PI*2,r=69+20*Math.cos(a*5);d+=(j?'L':'M')+(110+Math.cos(a)*r).toFixed(2)+','+(110+Math.sin(a)*r).toFixed(2)}return d+'Z';
};
const flowerPath=petalOutline();
const Botanical:React.FC<{x?:number;y?:number;size?:number;rotate?:number;opacity?:number;delay?:number;color?:string}>=({x=30,y=1000,size=650,rotate=0,opacity=.38,delay=0,color=C.gold})=>{
 const f=useCurrentFrame(),{fps}=useVideoConfig();const p=interpolate(f,[delay,delay+fps*1.4],[0,1],clamp);
 return <svg viewBox="0 0 460 650" width={size*.7077} height={size} style={{position:'absolute',left:x,top:y,opacity,rotate:`${rotate}deg`,overflow:'visible'}} fill="none" stroke={color} strokeWidth="2">
  <path d="M225 630 C170 485 347 350 230 215 C220 201 210 195 190 183" pathLength="1" strokeDasharray="1" strokeDashoffset={1-p}/>
  <path d="M224 540 C132 537 112 478 145 464 C185 462 210 501 224 540 M233 452 C315 442 345 388 321 369 C280 367 244 414 233 452 M260 366 C188 358 165 308 185 291 C225 292 254 335 260 366 M251 275 C315 278 342 231 324 215 C288 211 259 246 251 275" pathLength="1" strokeDasharray="1" strokeDashoffset={1-p}/>
  <g transform="translate(85 15)"><path d={flowerPath} pathLength="1" strokeDasharray="1" strokeDashoffset={1-p}/><path d="M112 61 C66 52 59 111 92 134 C139 166 175 110 140 80 C103 49 72 95 100 114 C119 130 140 101 121 94 C108 89 104 104 114 107" pathLength="1" strokeDasharray="1" strokeDashoffset={1-p}/></g>
 </svg>;
};

// Character mask technique adapted from remotion-scenes TextMaskReveal (MIT).
const KineticWord:React.FC<{text:string;size:number;color?:string;delay?:number;mode?:Shot['mode'];center?:boolean}>=({text,size,color=C.cream,delay=0,mode='rise',center=false})=>{
 const f=useCurrentFrame(),{fps}=useVideoConfig();
 return <div style={{display:'flex',justifyContent:center?'center':'flex-start',fontFamily:'Anton',fontSize:size,lineHeight:1.08,color,whiteSpace:'nowrap',letterSpacing:-size*.018}}>{[...text].map((ch,i)=>{
  const p=spring({frame:f-delay-i*1.15,fps,config:{damping:24,stiffness:220,mass:.85}});
  const entered=Math.max(0,Math.min(1,p));const sign=mode==='split'&&i%2?-1:1;
  const wave=mode==='wave'?Math.sin(f/fps*2.4-i*.7)*5*entered:0;
  return <span key={i} style={{display:'inline-block',overflow:mode==='split'?'visible':'hidden',paddingBottom:size*.09,marginBottom:-size*.09}}><span style={{display:'inline-block',translate:`0px ${sign*(1-p)*size*1.15+wave}px`,rotate:`${(1-p)*(i%2?-11:11)}deg`,scale:`1 ${mode==='stretch'?1+(1-p)*.75:1}`,opacity:Math.min(1,entered*3)}}>{ch===' '?'\u00a0':ch}</span></span>;
 })}</div>;
};
const Head:React.FC<{s:Shot;center?:boolean}>=({s,center=false})=>{
 const f=useCurrentFrame(),{fps}=useVideoConfig();const top=s.anchor==='top'?220:s.anchor==='bottom'?1210:700;
 return <AbsoluteFill style={{padding:'0 76px',paddingTop:top,alignItems:center?'center':'flex-start',pointerEvents:'none'}}>
  {s.kicker&&<div style={{font:'31px Quiet',letterSpacing:4,color:C.cream,opacity:interpolate(f,[6,.4*fps],[0,1],clamp),marginBottom:32}}>{s.kicker}</div>}
  {(s.words||[]).map((w,i)=><KineticWord key={w} text={w} size={s.size||190} color={i%2?C.orange:C.cream} delay={6+i*4} mode={s.mode} center={center}/>)}
 </AbsoluteFill>;
};
const Footage:React.FC<{clip:string;offset?:number;style?:React.CSSProperties;dim?:number;contain?:boolean}>=({clip,offset=0,style={},dim=0,contain=false})=>{
 const {fps}=useVideoConfig();
 return <AbsoluteFill style={{...style,overflow:'hidden'}}><OffthreadVideo src={staticFile(`assets/bloom-${clip}.mp4`)} trimBefore={Math.round(offset*fps)} playbackRate={.85} muted style={{width:'100%',height:'100%',objectFit:contain?'contain':'cover'}}/>{dim>0&&<AbsoluteFill style={{background:C.black,opacity:dim}}/>}<AbsoluteFill style={{background:'radial-gradient(ellipse at center,transparent 40%,#00000055 100%)'}}/></AbsoluteFill>;
};
const Magnify=()=> <svg viewBox="0 0 64 64" width="48" height="48" fill="none" stroke="currentColor" strokeWidth="4"><circle cx="26" cy="26" r="17"/><path d="M39 39 58 58"/></svg>;
const Cursor:React.FC<{x:number;y:number;scale:number;opacity:number}>=({x,y,scale,opacity})=><svg width="80" height="92" viewBox="0 0 80 92" style={{position:'absolute',left:x,top:y,scale,opacity,filter:'drop-shadow(0 4px 6px #00000066)'}}><path d="M5 4 64 48 36 54 24 80Z" fill={C.orange} stroke={C.black} strokeWidth="3"/><path d="M36 54 51 78" stroke={C.orange} strokeWidth="12"/></svg>;
export const SearchScene:React.FC=()=>{
 const f=useCurrentFrame(),{fps}=useVideoConfig();const m=motion.search[Math.min(Math.max(0,f),motion.search.length-1)];const name='Blumenpyramide';const chars=Math.floor(interpolate(f,[.48*fps,1.72*fps],[0,name.length],clamp));
 return <AbsoluteFill style={{overflow:'hidden'}}><Atmosphere forest/><Moon/><Botanical x={-180} y={1110} size={960} rotate={-24} opacity={.36}/><Botanical x={850} y={-140} size={760} rotate={165} opacity={.16}/>
  <div style={{position:'absolute',left:76,top:360,color:C.gold,font:'31px Quiet',letterSpacing:4}}>HALLOWEEN IN VOLLER BLÜTE</div>
  <div style={{position:'absolute',left:76,top:480}}><KineticWord text="ETWAS" size={178} delay={0} mode="split"/><KineticWord text="MAGISCHES." size={178} delay={5} mode="split" color={C.orange}/></div>
  <div style={{position:'absolute',left:80,top:890,width:920,height:146,borderRadius:76,background:C.cream,color:C.black,display:'flex',alignItems:'center',gap:30,padding:'0 27px 0 38px',transform:`translate(${m.bar.x}px,${m.bar.y}px) scale(${m.bar.scale})`,opacity:m.bar.opacity,boxShadow:'0 25px 90px #00000044'}}>
   <Magnify/><div style={{font:'49px Quiet',flex:1,whiteSpace:'nowrap',display:'flex',alignItems:'center'}}>{name.slice(0,chars)}<span style={{height:55,width:3,background:C.green,marginLeft:5,opacity:f<108&&Math.floor(f/14)%2===0?1:0}}/></div>
   <div style={{width:94,height:94,borderRadius:50,background:C.green,color:C.cream,display:'flex',alignItems:'center',justifyContent:'center',font:'62px Quiet'}}>↵</div>
  </div>
  <div style={{position:'absolute',top:1140,left:80,font:'39px Quiet',color:C.cream,opacity:interpolate(f,[.6*fps,1*fps],[0,.8],clamp)}}>Herbstkreationen entdecken.</div>
  <Cursor {...m.cursor}/>
 </AbsoluteFill>;
};
const Shutter:React.FC<{s:Shot}>=({s})=>{
 const f=useCurrentFrame(),{fps}=useVideoConfig();const dark=s.tone==='dark';const bg=dark?C.black:C.orange;const color=dark?C.cream:C.black;
 return <AbsoluteFill style={{background:bg,overflow:'hidden'}}>{dark&&<Atmosphere/>}<Moon opacity={dark?.5:.15}/>
  <div style={{position:'absolute',top:780,width:1080,height:390}}>{[0,1,2].map((j)=>{
   const p=spring({frame:f-j*3,fps,config:{damping:25,stiffness:240,mass:.9}});return <div key={j} style={{position:'absolute',inset:0,clipPath:`inset(${j*33.33}% 0 ${(2-j)*33.33}% 0)`,font:`${s.size||260}px Anton`,letterSpacing:-5,color,textAlign:'center',translate:`${(j%2?-1:1)*(1-p)*700}px 0px`}}>{s.words?.[0]}</div>;
  })}</div>
  <div style={{position:'absolute',top:1360,left:80,font:'31px Quiet',letterSpacing:5,color,opacity:.7}}>DIE FACETTEN DES HERBSTES</div>
 </AbsoluteFill>;
};
const Ribbon:React.FC<{s:Shot}>=({s})=>{
 const f=useCurrentFrame(),{fps}=useVideoConfig();const dark=s.tone==='dark';const p=spring({frame:f,fps,config:{damping:25,stiffness:190}});const text=s.words?.[0]||'FLORAL.';
 return <AbsoluteFill style={{background:dark?C.black:C.cream,overflow:'hidden'}}>
  {dark&&<Atmosphere/>}<Botanical x={40} y={50} size={850} opacity={dark?.25:.35} color={dark?C.gold:C.green} rotate={-30}/>
  {[-1,1].map((v,j)=><div key={v} style={{position:'absolute',left:-180,top:730+j*270,width:1500,height:280,background:j===0?C.orange:C.wine,rotate:`${v*10}deg`,translate:`${(1-p)*v*1200}px 0px`,overflow:'hidden',display:'flex',alignItems:'center'}}><div style={{font:'180px Anton',whiteSpace:'nowrap',color:j?C.cream:C.black,translate:`${-260+v*f/fps*155}px 0px`,letterSpacing:-4}}>{Array(5).fill(text).join('  ')}</div></div>)}
 </AbsoluteFill>;
};
const DateScene:React.FC=()=>{
 const f=useCurrentFrame(),{fps}=useVideoConfig();const p=spring({frame:f,fps,config:{damping:25,stiffness:210}});
 return <AbsoluteFill style={{overflow:'hidden'}}><Atmosphere/><Botanical x={-140} y={820} size={1080} opacity={.27} rotate={-14}/><Moon x={790} y={210} size={150}/>
  <svg width="1080" height="1920" style={{position:'absolute'}}><ellipse cx="540" cy="850" rx="486" ry="192" fill="none" stroke={C.gold} strokeWidth="2" opacity=".38" transform={`rotate(${-18+f/fps*4} 540 850)`}/><ellipse cx="540" cy="850" rx="420" ry="150" fill="none" stroke={C.wine} strokeWidth="2" transform={`rotate(${25-f/fps*6} 540 850)`}/></svg>
  <div style={{position:'absolute',top:500,width:1080,textAlign:'center',font:'330px Anton',color:C.orange,letterSpacing:-8,translate:`0px ${(1-p)*100}px`,scale:`1 ${1+(1-p)*.35}`}}>31.10</div>
  <div style={{position:'absolute',top:930,width:1080}}><KineticWord text="HALLOWEEN" size={170} color={C.cream} delay={7} center mode="split"/></div>
  <div style={{position:'absolute',top:1210,width:1080,textAlign:'center',font:'37px Quiet',letterSpacing:7,color:C.gold,opacity:interpolate(f,[.2*fps,.65*fps],[0,1],clamp)}}>SPÜRBAR MAGISCH.</div>
 </AbsoluteFill>;
};
const Haunted:React.FC=()=>{
 const f=useCurrentFrame(),{fps}=useVideoConfig();const p=spring({frame:f-2,fps,config:{damping:26,stiffness:190}});
 return <AbsoluteFill style={{overflow:'hidden'}}><Atmosphere forest/><Moon x={90} y={220} size={130}/><Botanical x={730} y={1090} size={810} rotate={22} opacity={.3}/>
  <div style={{position:'absolute',top:570,width:1080,fontFamily:'Anton',fontSize:320,lineHeight:.98,letterSpacing:-9,textAlign:'center'}}>{['HALLO','WEEN.'].map((text,i)=><div key={text} style={{position:'relative',color:i?C.orange:C.cream,translate:`${(i?-1:1)*(1-p)*850}px 0px`,scale:`${1+(1-p)*.35} 1`}}><span style={{position:'absolute',inset:0,WebkitTextStroke:`2px ${C.gold}`,color:'transparent',translate:`${i?-16:16}px ${i?14:-14}px`,opacity:.35}}>{text}</span><span style={{position:'relative'}}>{text}</span></div>)}</div>
  <div style={{position:'absolute',top:1370,width:1080,textAlign:'center',font:'40px Quiet',color:C.cream}}>Dunkel. Elegant. Voller Leben.</div>
 </AbsoluteFill>;
};
const LogoPlaque:React.FC<{reveal?:boolean}>=({reveal=false})=>{
 const f=useCurrentFrame(),{fps}=useVideoConfig();const p=spring({frame:f-2,fps,config:{damping:30,stiffness:150,mass:.8}});
 return <div style={{position:'absolute',left:80,top:350,width:920,height:920,borderRadius:28,overflow:'hidden',clipPath:reveal?`circle(${Math.max(0,p)*720}px at 50% 50%)`:'none',opacity:reveal?Math.min(1,p*2):1}}><Img src={staticFile('assets/blumenpyramide-logo.png')} style={{width:'100%',height:'100%',objectFit:'contain'}}/></div>;
};
const ResultScene:React.FC=()=>{
 const f=useCurrentFrame();const a=motion.result[Math.min(Math.max(0,f),motion.result.length-1)];
 return <AbsoluteFill style={{overflow:'hidden'}}><Atmosphere forest/><Moon opacity={.5}/><Botanical x={-180} y={880} size={1000} opacity={.28} rotate={-25}/>
  <div style={{position:'absolute',left:80,top:570,width:920,translate:`${a.x}px ${a.y}px`,scale:a.scale,rotate:`${a.rotation}deg`,opacity:a.opacity,transformOrigin:'50% 55%'}}>
   <div style={{height:128,border:'2px solid #dcb66c77',borderRadius:70,background:'#041e15',color:C.cream,display:'flex',gap:28,alignItems:'center',padding:'0 34px',font:'48px Quiet'}}><Magnify/>Blumenpyramide<span style={{marginLeft:'auto',color:C.gold}}>✓</span></div>
   <div style={{background:C.cream,marginTop:32,borderRadius:28,padding:'42px',display:'flex',gap:36,alignItems:'center',color:C.black}}><Img src={staticFile('assets/blumenpyramide-logo.png')} style={{width:190,height:190,borderRadius:12}}/><div style={{flex:1}}><div style={{font:'58px Anton'}}>GEFUNDEN.</div><div style={{font:'35px Quiet',marginTop:18}}>Ihre Herbstkreationen.</div></div><span style={{font:'66px Quiet'}}>↗</span></div>
  </div>
 </AbsoluteFill>;
};
const ShotScene:React.FC<{s:Shot;index:number}>=({s,index})=>{
 const f=useCurrentFrame(),{fps}=useVideoConfig();const roll=spring({frame:f-3,fps,config:{damping:27,stiffness:190}});
 if(s.kind==='search')return <SearchScene/>;
 if(s.kind==='shutter')return <Shutter s={s}/>;
 if(s.kind==='ribbon')return <Ribbon s={s}/>;
 if(s.kind==='date')return <DateScene/>;
 if(s.kind==='haunted')return <Haunted/>;
 if(s.kind==='result')return <ResultScene/>;
 if(s.kind==='type')return <AbsoluteFill style={{background:C.cream,alignItems:'center',justifyContent:'center'}}><Botanical x={590} y={780} size={800} color={C.green} opacity={.24} rotate={25}/><KineticWord text={s.words?.[0]||''} size={s.size||280} color={C.black} mode="wave" center/></AbsoluteFill>;
 if(s.kind==='botanical')return <AbsoluteFill><Atmosphere forest/><Moon x={820} y={230} size={130}/><Botanical x={-200} y={680} size={1220} opacity={.62} rotate={-19}/><Botanical x={870} y={470} size={1040} opacity={.42} rotate={20} delay={8}/><Head s={s} center/><div style={{position:'absolute',top:1320,width:1080,textAlign:'center',font:'36px Quiet',color:C.gold}}>Herbstzauber, der bleibt.</div></AbsoluteFill>;
 if(s.kind==='cutout')return <AbsoluteFill style={{background:C.cream,alignItems:'center',justifyContent:'center'}}>
  <div style={{position:'absolute',top:260,left:80,font:'32px Quiet',letterSpacing:6,color:C.green}}>HERBSTZAUBER</div><Botanical x={720} y={-110} size={820} color={C.green} opacity={.22} rotate={155}/>
  <svg width="1080" height="1920" style={{position:'absolute'}}><defs><clipPath id="living-type"><text x="540" y="1080" textAnchor="middle" fontFamily="Anton" fontSize="360" letterSpacing="-8">BLÜTE</text></clipPath></defs></svg>
  <div style={{position:'absolute',inset:0,clipPath:'url(#living-type)',translate:`0px ${(1-roll)*90}px`}}><Footage clip="pink" offset={.2}/></div>
  <div style={{position:'absolute',bottom:300,font:'37px Quiet',color:C.green}}>DIE SCHÖNSTE SPRACHE DES HERBSTES.</div>
 </AbsoluteFill>;
 if(s.kind==='triptych')return <AbsoluteFill><Atmosphere/><div style={{position:'absolute',left:0,top:660,width:1080,height:980,display:'flex',gap:12,translate:`0px ${(1-roll)*150}px`}}>{['amber','red','golden'].map((name,j)=><div key={name} style={{position:'relative',width:352,height:980,overflow:'hidden',marginTop:j===1?100:0}}><Footage clip={name} offset={j*.1} dim={.05}/></div>)}</div><Head s={s}/></AbsoluteFill>;
 if(s.kind==='split')return <AbsoluteFill style={{background:C.black,overflow:'hidden'}}><div style={{position:'absolute',left:110,top:670,width:1120,height:1120,translate:`${(1-roll)*160}px 0px`}}><Footage clip={s.clip||'golden'} dim={.18}/></div><div style={{position:'absolute',left:0,top:540,bottom:0,width:20,background:C.orange,scale:`1 ${roll}`,transformOrigin:'top'}}/><Head s={s}/></AbsoluteFill>;
 if(s.kind==='bloom')return <AbsoluteFill style={{background:C.black,overflow:'hidden'}}><Footage clip={s.clip||'peach'} offset={s.offset} style={{top:s.anchor==='top'?650:100,height:1220,left:-90,width:1260}} dim={.06}/><Head s={s}/><Moon x={875} y={180} size={100} opacity={.4}/></AbsoluteFill>;
 if(s.kind==='logo'||s.kind==='final')return <AbsoluteFill><Atmosphere forest/><Botanical x={-220} y={1080} size={1050} opacity={.25} rotate={-30}/><Botanical x={920} y={-80} size={1000} opacity={.18} rotate={160}/><div style={{position:'absolute',top:220,width:1080,textAlign:'center',font:'31px Quiet',letterSpacing:6,color:C.gold}}>HERBST & HALLOWEEN</div><LogoPlaque reveal={s.kind==='logo'}/>
  {s.kind==='final'&&<><div style={{position:'absolute',top:1330,width:1080,textAlign:'center',font:'40px Quiet',color:C.cream}}>Herbstzauber in voller Blüte.</div><div style={{position:'absolute',left:190,top:1480,width:700,height:134,display:'flex',alignItems:'center',justifyContent:'center',gap:60,background:C.orange,color:C.black,font:'48px Anton',borderRadius:3,translate:`0px ${(1-roll)*65}px`,opacity:Math.min(1,roll*2)}}>JETZT BESTELLEN <span style={{font:'62px Quiet'}}>↗</span></div></>}
 </AbsoluteFill>;
 return <AbsoluteFill style={{background:C.black}}><Footage clip={s.clip||'red'} offset={s.offset} dim={index===16?.65:index===6?.38:.38}/><Head s={s} center={s.anchor==='center'}/>{index===6&&<Moon x={860} y={210} size={110} opacity={.6}/>}</AbsoluteFill>;
};

const Push:React.FC<TransitionPresentationComponentProps<{direction:number}>>=({children,presentationDirection,presentationProgress:p,passedProps})=>{
 const enter=presentationDirection==='entering';const scale=enter?1.12-.12*p:1+.18*p;
 return <AbsoluteFill style={{opacity:enter?p:1,scale,translate:`${(enter?1-p:-p)*passedProps.direction*70}px 0px`,filter:`blur(${(enter?1-p:p)*3}px)`}}>{children}</AbsoluteFill>;
};
const push=(direction:number)=>({component:Push,props:{direction}});
export const BlumenpyramideV4:React.FC=()=>{
 const {fps}=useVideoConfig();const [handle]=useState(()=>delayRender('Loading campaign fonts'));
 useEffect(()=>{Promise.all([document.fonts.load('190px Anton'),document.fonts.load('48px Quiet'),document.fonts.load('92px Atelier')]).then(()=>continueRender(handle));},[handle]);
 return <AbsoluteFill style={{background:C.black,overflow:'hidden'}}><style>{fontCSS}</style><TransitionSeries>{shots.map((s,i)=><React.Fragment key={i}>
  <TransitionSeries.Sequence durationInFrames={at(s.end)-at(s.start)+(i<shots.length-1?transitionFrames(i):0)} premountFor={fps}><ShotScene s={s} index={i}/></TransitionSeries.Sequence>
  {i<shots.length-1&&(s.transition==='zoom'?<TransitionSeries.Transition timing={linearTiming({durationInFrames:transitionFrames(i),easing:Easing.inOut(Easing.cubic)})} presentation={push(0)}/>:s.transition==='warp'?<TransitionSeries.Transition timing={linearTiming({durationInFrames:transitionFrames(i),easing:Easing.inOut(Easing.cubic)})} presentation={crosswarp({})}/>:s.transition==='wipe'?<TransitionSeries.Transition timing={linearTiming({durationInFrames:transitionFrames(i),easing:Easing.inOut(Easing.cubic)})} presentation={wipe({direction:i%2?'from-left':'from-bottom'})}/>:s.transition==='slide'?<TransitionSeries.Transition timing={linearTiming({durationInFrames:transitionFrames(i),easing:Easing.inOut(Easing.cubic)})} presentation={slide({direction:i%2?'from-right':'from-top'})}/>:<TransitionSeries.Transition timing={linearTiming({durationInFrames:transitionFrames(i),easing:Easing.inOut(Easing.cubic)})} presentation={push(i%2?1:-1)}/>)}
 </React.Fragment>)}</TransitionSeries><Audio src={staticFile('assets/spooky-floral-119.wav')} volume={.9}/></AbsoluteFill>;
};
const Root=()=> <Composition id="BlumenpyramideV4" component={BlumenpyramideV4} width={1080} height={1920} fps={60} durationInFrames={2118}/>;
registerRoot(Root);
