# Blumenpyramide V4 — Spooky in Bloom

<design_plan>
Hero: search bar transforms into the film. Components selected with Python seed 11970: crescent-orbit date, botanical linework, split text shutters. GSAP animates the elastic search bar, click rebound and zoom; motion samples are baked at 60fps for deterministic Remotion seeking. Approved typography is preserved: Anton, Quiet and Atelier, plus the supplied logo image. Film AIDA: search hook; flowers and kinetic qualities; spooky floral identity; result-card, brand and order. Headlines occupy at most two lines. Side inset 76px; final CTA stays above 1600px. A triptych uses 3x352 + 2x12 =1080px, with no gaps beyond the gutters. Cream on black, black on cream, orange only over darkened footage.
</design_plan>

## Palette
Ink #090806; forest #042f20; parchment #f8efd9; orange #f16c2e; wine #6a142a; gold #dcb66c. Green makes the supplied logo belong to the film. Wine glows and a drawn crescent give the Halloween atmosphere.

## Motion and pacing
119 BPM, exactly 15% below V3's 140. Seventy beats last 35.3 seconds at 60fps. Twenty sequences. Search typing, elastic rebound, zoom-through, letter shutters, counter-moving ribbons, large masked text, botanical paths drawn over time and a logo iris reveal. Soft temporal ramps; no uncontrolled shaking, no decorative falling petals. Natural flower-opening footage remains.

## Sound
Original minor-key score at 119 BPM. Restrained four-beat groove, low bass pulse, music-box bells, airy reversed accents, search typing and click. No voiceover, no horror shrieks.

## Identity
Logo image prepared from the image supplied in the conversation, preserving its floral pyramid, green, gold and lettering. The final plaque and its order CTA remain readable for the last three-and-a-half seconds together.
