import pkg from 'gsap/dist/gsap.js';
import {writeFileSync} from 'node:fs';
const {gsap}=pkg;
const bar={x:0,y:100,scale:.82,rotation:0,opacity:0};
const cursor={x:1060,y:1280,scale:1,opacity:0};
const card={x:0,y:140,scale:.82,rotation:-5,opacity:0};
const tl=gsap.timeline({paused:true});
tl.to(bar,{y:0,scale:1,opacity:1,duration:.62,ease:'back.out(1.4)'},.05)
 .to(cursor,{x:925,y:960,opacity:1,duration:.5,ease:'power3.out'},1.55)
 .to(cursor,{scale:.8,duration:.1,ease:'power2.in'},2.05)
 .to(bar,{scale:.96,rotation:-1,duration:.10,ease:'power2.in'},2.05)
 .to(bar,{scale:1.14,rotation:1.7,y:-58,duration:.18,ease:'power2.out'},2.15)
 .to(bar,{scale:1,rotation:0,y:0,duration:.23,ease:'back.out(2)'},2.33)
 .to(cursor,{opacity:0,duration:.15},2.4)
 .to(bar,{scale:5.5,y:-80,rotation:-4,opacity:0,duration:.58,ease:'power3.in'},2.72);
const rt=gsap.timeline({paused:true});
rt.to(card,{y:0,scale:1,rotation:0,opacity:1,duration:.50,ease:'back.out(1.35)'},0)
 .to(card,{scale:.965,duration:.08},.85)
 .to(card,{scale:1.06,duration:.14,ease:'power2.out'},.93)
 .to(card,{scale:1,duration:.17,ease:'back.out(2)'},1.07)
 .to(card,{scale:3.7,y:-90,opacity:0,duration:.45,ease:'power3.in'},1.30);
const search=[],result=[];
for(let f=0;f<=240;f++){tl.seek(f/60,false);search.push({bar:{...bar,_gsap:undefined},cursor:{...cursor,_gsap:undefined}});rt.seek(f/60,false);result.push({...card,_gsap:undefined});}
writeFileSync('src/gsap-motion.json',JSON.stringify({fps:60,search,result}));
gsap.ticker.sleep();console.log('GSAP motion sampled at 60fps.');
