import {resolve} from 'node:path';
import {bundle} from '@remotion/bundler';
import {selectComposition,renderStill,renderMedia,openBrowser} from '@remotion/renderer';
import {writeFileSync,mkdirSync} from 'node:fs';
mkdirSync('deliverables',{recursive:true});
const serveUrl=await bundle({entryPoint:resolve('src/index.tsx'),publicDir:resolve('public'),outDir:resolve('build'),onProgress:()=>{}});
const browser=await openBrowser('chrome',{browserExecutable:'/usr/bin/chromium',chromiumOptions:{gl:'swangle'}});
const composition=await selectComposition({serveUrl,id:'BlumenpyramideV4',puppeteerInstance:browser});
console.log('Composition',composition.width,composition.height,composition.durationInFrames,'60 fps');
const logs=[];const log=({type,text})=>{if(type==='error')logs.push(text)};
try{
 if(process.argv.includes('--search-check')){
  for(const frame of [138,166,180])await renderStill({serveUrl,composition,frame,output:`deliverables/search-fixed-${frame}.jpg`,imageFormat:'jpeg',scale:.5,puppeteerInstance:browser,browserExecutable:'/usr/bin/chromium',chromiumOptions:{gl:'swangle'},onBrowserLog:log});
 }else if(process.argv.includes('--search-only')){
  await renderMedia({serveUrl,composition,codec:'h264',outputLocation:'deliverables/patch-search-fixed.mp4',frameRange:[0,197],crf:18,scale:1,concurrency:2,puppeteerInstance:browser,browserExecutable:'/usr/bin/chromium',chromiumOptions:{gl:'swangle'},onBrowserLog:log});console.log('Search transform corrected');
 }else if(process.argv.includes('--patches')){
  for(const [name,start,end] of [['search',0,197],['bloom-a',424,560],['bloom-b',1150,1286],['split',1331,1467]]){
   await renderMedia({serveUrl,composition,codec:'h264',outputLocation:`deliverables/patch-${name}.mp4`,frameRange:[start,end],crf:18,scale:1,concurrency:2,puppeteerInstance:browser,browserExecutable:'/usr/bin/chromium',chromiumOptions:{gl:'swangle'},onBrowserLog:log});console.log('Corrected',name,start,end);
  }
 }else if(process.argv.includes('--stills')){
  const stills=[['search-typing',75],['search-complete',115],['search-bounce',145],['shutter',340],['type',398],['ribbons',580],['halloween',790],['haunted',920],['botanical',1030],['living-type',1512],['gallery',1630],['invitation',1750],['result',1860],['logo',1960],['final',2070]];
  for(const [name,frame] of stills){await renderStill({serveUrl,composition,frame,output:`deliverables/${name}.jpg`,imageFormat:'jpeg',scale:.5,puppeteerInstance:browser,browserExecutable:'/usr/bin/chromium',chromiumOptions:{gl:'swangle'},onBrowserLog:log});console.log('Still',name,frame);}
 }else{
  let bucket=-1;
  await renderMedia({serveUrl,composition,codec:'h264',outputLocation:'deliverables/Blumenpyramide-V4-Spooky-Floral-HD.mp4',crf:18,scale:1,concurrency:2,puppeteerInstance:browser,browserExecutable:'/usr/bin/chromium',chromiumOptions:{gl:'swangle'},onBrowserLog:log,onProgress:p=>{const b=Math.floor(p.progress*100);if(b!==bucket){bucket=b;console.log('Progress',b+'%',p.renderedFrames,'/',p.encodedFrames);writeFileSync('deliverables/render-progress.json',JSON.stringify({progress:p.progress,rendered:p.renderedFrames,encoded:p.encodedFrames}));}}});
  console.log('Rendered V4');
 }
 writeFileSync('deliverables/browser-errors.json',JSON.stringify(logs));
 if(logs.length)throw new Error(`${logs.length} browser errors; inspect browser-errors.json`);
}finally{await browser.close({silent:true});}
