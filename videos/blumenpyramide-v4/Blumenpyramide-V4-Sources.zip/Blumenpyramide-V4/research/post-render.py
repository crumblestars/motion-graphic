from pathlib import Path
import subprocess,json,hashlib
from PIL import Image,ImageDraw,ImageFont
root=Path.cwd();out=root/'deliverables';master=out/'Blumenpyramide-V4-Spooky-Floral-HD.mp4';light=out/'Blumenpyramide-V4-Spooky-Floral-leger.mp4'
subprocess.run(['ffmpeg','-y','-hide_banner','-loglevel','error','-i',str(master),'-vf','scale=720:1280:flags=lanczos','-c:v','libx264','-preset','fast','-crf','25','-maxrate','2400k','-bufsize','4800k','-threads','2','-pix_fmt','yuv420p','-c:a','aac','-b:a','128k','-movflags','+faststart',str(light)],check=True)
validation={}
for p,dimensions in [(master,(1080,1920)),(light,(720,1280))]:
 meta=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration,size:stream=codec_name,width,height,r_frame_rate,nb_frames,channels,sample_rate','-of','json',str(p)]))
 assert abs(float(meta['format']['duration'])-35.3)<.04
 v=next(x for x in meta['streams'] if x['codec_name']=='h264');a=next(x for x in meta['streams'] if x['codec_name']=='aac')
 assert (v['width'],v['height'])==dimensions and v['nb_frames']=='2118' and v['r_frame_rate']=='60/1' and a['channels']==2
 subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-xerror','-i',str(p),'-f','null','-'],check=True)
 validation[p.name]={'metadata':meta,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'full_decode':'passed'}
(out/'VALIDATION.json').write_text(json.dumps(validation,indent=2));print('Both MP4s decode cleanly: 2118 frames at 60fps.',flush=True)
beats=[(0,6),(6,10),(10,12),(12,14),(14,18),(18,20),(20,24),(24,28),(28,32),(32,36),(36,38),(38,42),(42,44),(44,48),(48,52),(52,56),(56,60),(60,63),(63,66),(66,70)]
board=Image.new('RGB',(1080,1664),'#090806');draw=ImageDraw.Draw(board);font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',15);frames=out/'qa-frames';frames.mkdir(exist_ok=True)
for i,(a,b) in enumerate(beats):
 t=(a+b)/2*60/119;p=frames/f'{i+1:02}.jpg'
 subprocess.run(['ffmpeg','-y','-hide_banner','-loglevel','error','-ss',str(t),'-i',str(master),'-frames:v','1','-vf','scale=216:384','-q:v','2',str(p)],check=True)
 x=i%5*216;y=i//5*416;board.paste(Image.open(p),(x,y));draw.text((x+8,y+392),f'{i+1:02} / {a*60/119:04.1f}–{b*60/119:04.1f}s',fill='#f8efd9',font=font)
board.save(out/'Storyboard-V4.jpg',quality=92)
subprocess.run(['ffmpeg','-y','-hide_banner','-loglevel','error','-ss','34.5','-i',str(master),'-frames:v','1','-q:v','2',str(out/'Affiche-V4.jpg')],check=True)
print('Delivery copies, full decode checks, storyboard and poster complete.',flush=True)
