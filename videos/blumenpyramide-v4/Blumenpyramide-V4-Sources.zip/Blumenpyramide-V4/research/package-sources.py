from pathlib import Path
import zipfile
root=Path.cwd();target=root/'deliverables/Blumenpyramide-V4-Sources.zip'
paths=[root/n for n in ['package.json','package-lock.json','tsconfig.json','DESIGN.md','README-FR.md','MEDIA-CREDITS.md','index.html']]
for folder in ['src','public','licenses']:
 paths.extend(p for p in (root/folder).rglob('*') if p.is_file())
for name in ['bake-gsap.mjs','music-v4.py','render-v4.mjs','post-render.py','package-sources.py','prepare-footage.py','footage-map.json','provenance.json','design-plan.json','studio-validation.json','blooming-data-original-credits.html']:
 paths.append(root/'research'/name)
for name in ['Blumenpyramide-V4-Spooky-Floral-HD.mp4','VALIDATION.json','Storyboard-V4.jpg','Affiche-V4.jpg','hyperframes-check.json','browser-errors.json']:
 p=root/'deliverables'/name
 if p.exists():paths.append(p)
with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in paths:z.write(p,Path('Blumenpyramide-V4')/p.relative_to(root))
with zipfile.ZipFile(target) as z:assert z.testzip() is None
print('Source archive:',target.stat().st_size,'bytes;',len(paths),'files')
