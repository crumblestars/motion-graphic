import numpy as np,wave,json
from scipy.signal import butter,sosfilt
sr=44100;duration=35.3;n=round(sr*duration);beat=60/119;rng=np.random.default_rng(11970)
mix=np.zeros((n,2));bed=np.zeros((n,2))
def put(dest,start,x,g=1,pan=0):
 i=max(0,round(start*sr));amount=min(n-i,len(x))
 if amount<=0:return
 dest[i:i+amount,0]+=x[:amount]*g*np.sqrt((1-pan)/2);dest[i:i+amount,1]+=x[:amount]*g*np.sqrt((1+pan)/2)
def hz(m):return 440*2**((m-69)/12)
def low(x,f):return sosfilt(butter(2,f,fs=sr,output='sos'),x)
def bell(m,length=2.8):
 t=np.arange(round(sr*length))/sr;f=hz(m)
 x=sum(a*np.sin(2*np.pi*f*k*t)*np.exp(-t*r) for k,a,r in [(1,1,2.7),(2.01,.4,4.2),(3.98,.17,6),(5.07,.06,8)])
 return x*(1-np.exp(-t*250))
def bass(m):
 t=np.arange(round(sr*.52))/sr
 return (np.sin(2*np.pi*hz(m)*t)+.16*np.sin(2*np.pi*2*hz(m)*t))*np.minimum(1,t/.025)*np.exp(-t*5)
chords=[[50,57,62,65],[46,53,58,62],[43,50,55,58],[45,52,57,61]]
for bar in range(18):
 ch=chords[bar%4];start=bar*4*beat
 t=np.arange(round(sr*3.0))/sr;env=np.minimum(1,t/.45)*np.minimum(1,(3-t)/.9)
 pad=sum(np.sin(2*np.pi*hz(m)*t)+.12*np.sin(2*np.pi*2*hz(m)*t) for m in ch)/4
 put(bed,start,pad*env,.14,(-1)**bar*.12)
 for k,m in enumerate([ch[2]+12,ch[3]+12,ch[1]+12,ch[3]+12]):
  put(bed,start+k*beat,bell(m),.075 if k%2==0 else .045,(-1)**k*.3)
 for k in [0,1.5,2,3.5]:put(bed,start+k*beat,bass(ch[0]-12),.27)
 if bar%2==0:put(bed,start+3*beat,bell([86,89,84,85][(bar//2)%4],3.2),.055,-.25)
for b in range(6,70):
 start=b*beat;t=np.arange(round(sr*.30))/sr
 kick=np.sin(2*np.pi*(44*t+2*(1-np.exp(-t*30))))*np.exp(-t*16)
 put(mix,start,kick,.43 if b%4 in [0,2] else .33)
 if b%4 in [1,3]:
  t=np.arange(round(sr*.15))/sr;noise=rng.normal(size=len(t));noise=noise-low(noise,2100)
  put(mix,start,noise*np.exp(-t*42),.028,(-1)**b*.1)
 for offset,g in [(0,.010),(.5,.018)]:
  t=np.arange(round(sr*.075))/sr;noise=rng.normal(size=len(t));high=noise-low(noise,6500)
  put(mix,start+offset*beat,high*np.exp(-t*70),g,(-1)**b*.35)
 lo=round(start*sr);hi=min(n,round((start+beat)*sr));tt=np.arange(hi-lo)/sr
 bed[lo:hi]*=(.68+.32*(1-np.exp(-tt*16)))[:,None]
# A breath-like tonal wind, deliberately subtle and without horror shrieks.
t=np.arange(n)/sr;air=low(rng.normal(size=n),1100);air=air-low(air,170)
put(mix,0,air*(.6+.4*np.sin(t*.3)**2),.013)
# Search keystrokes and the two visible clicks are part of the original score.
for i in range(len('Blumenpyramide')):
 start=.48+i*1.24/len('Blumenpyramide');t=np.arange(round(sr*.025))/sr
 click=(rng.normal(size=len(t))*.3+np.sin(2*np.pi*1900*t))*np.exp(-t*190)
 put(mix,start,click,.035,(-1)**i*.13)
for start in [2.05,60*beat+.89]:
 t=np.arange(round(sr*.09))/sr;click=(np.sin(2*np.pi*780*t)+.25*rng.normal(size=len(t)))*np.exp(-t*65)
 put(mix,start,click,.10)
for b in [6,14,20,24,28,32,38,44,48,52,56,60,63]:
 t=np.arange(round(sr*.48))/sr;noise=low(rng.normal(size=len(t)),3200);envelope=np.sin(np.linspace(0,np.pi,len(t)))**2
 put(mix,b*beat-.17,noise*envelope,.025,(-1)**b*.22)
# Low resolving bell for the supplied logo and a warm final chord.
put(bed,63*beat,bell(74,3.0),.12)
put(bed,66*beat,bell(86,2.8),.08,.2)
dry=bed.copy()
for sec,g in [(beat*.75,.18),(beat*1.5,.10),(beat*3,.05)]:
 d=round(sec*sr);bed[d:]+=dry[:-d,::-1]*g
mix+=bed;fadein=np.minimum(1,np.arange(n)/sr/.12);fadeout=np.minimum(1,(n-1-np.arange(n))/sr/.80)
mix=np.tanh(mix*1.1)*(fadein*fadeout)[:,None];mix*=.86/max(np.max(np.abs(mix)),1e-6)
with wave.open('public/assets/spooky-floral-119.wav','wb') as w:
 w.setnchannels(2);w.setsampwidth(2);w.setframerate(sr);w.writeframes((mix*32767).astype('<i2').tobytes())
print('Original spooky floral score:',duration,'seconds; 119 BPM; peak',round(20*np.log10(np.max(abs(mix)))), 'dBFS')
