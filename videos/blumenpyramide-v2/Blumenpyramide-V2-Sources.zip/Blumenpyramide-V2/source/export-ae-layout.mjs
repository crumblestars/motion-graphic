import {chromium} from 'playwright-core';
import {writeFileSync,readFileSync} from 'node:fs';
const b=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});
const p=await b.newPage({viewport:{width:1080,height:1920}});await p.goto('http://127.0.0.1:9042');await p.evaluate(async()=>{await document.fonts.ready;return true});
const edit=JSON.parse(readFileSync('source/edit-map.json'));
const scenes=[];
for(let i=0;i<14;i++){
 await p.evaluate(t=>{tl.seek(t);return true},edit[i].start+Math.min(1.2,(edit[i].end-edit[i].start)/2+.3));
 scenes.push(await p.evaluate(i=>{
  const s=document.querySelector('#s'+i), box=e=>{const b=e.getBoundingClientRect();return{x:b.x,y:b.y,w:b.width,h:b.height}}, matrix=e=>{const m=new DOMMatrix(getComputedStyle(e).transform);return {angle:Math.atan2(m.b,m.a)*180/Math.PI,scale:Math.sqrt(m.a*m.a+m.b*m.b)}};
  const texts=[...s.querySelectorAll('.eyebrow,h1>.line,.note,.tagline,.closing,.product-card>p,.gift-tag>span,.gift-tag>strong,.gift-tag>i,.cta')].map(e=>{const c=getComputedStyle(e);return{...box(e),text:c.textTransform==='uppercase'?e.textContent.toUpperCase():e.textContent,size:parseFloat(c.fontSize),font:c.fontFamily,color:c.color,center:c.textAlign==='center'||e.classList.contains('cta'),tracking:parseFloat(c.letterSpacing)||0,italic:c.fontStyle==='italic',rotation:matrix(e).angle}});
  const images=[...s.querySelectorAll('img')].map(e=>{let angle=0,scale=1,a=e;while(a&&a!==s){const m=matrix(a);angle+=m.angle;scale*=m.scale;a=a.parentElement}return{...box(e),source:e.getAttribute('src'),width:e.clientWidth,angle,scale,cover:e.classList.contains('full-photo')||e.parentElement.classList.contains('photo-window')}});
  const shapes=[...s.querySelectorAll('.product-card,.gift-tag,.cta,.short-rule')].map(e=>{const c=getComputedStyle(e);return{...box(e),color:c.backgroundColor,border:c.borderTopColor,borderWidth:parseFloat(c.borderTopWidth),rotation:matrix(e).angle,round:parseFloat(c.borderTopLeftRadius)||0}});
  return{id:i,name:s.dataset.sceneName,background:getComputedStyle(s.querySelector('.stage')).backgroundColor,texts,images,shapes};
 },i));
}
await b.close();writeFileSync('source/ae-layout.json',JSON.stringify({edit,scenes},null,2));
console.log('Exported layered AE layout for fourteen scenes.');
