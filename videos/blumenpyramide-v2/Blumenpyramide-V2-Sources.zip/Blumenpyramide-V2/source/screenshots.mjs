import {chromium} from 'playwright-core';
import {readFileSync,writeFileSync} from 'node:fs';
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']});
const page=await browser.newPage({viewport:{width:1080,height:1920},deviceScaleFactor:.5});
const errors=[];const warnings=[];page.on('pageerror',e=>errors.push(String(e)));page.on('console',e=>{if(e.type()==='warning'||e.type()==='error')warnings.push(e.text())});
try{
 await page.goto('http://127.0.0.1:9042',{waitUntil:'load',timeout:20000});
 await page.evaluate(async()=>{await document.fonts.ready;return true});
 const times=[1.15,3,4.9,6.8,8.7,10.5,12.4,14.3,16.2,18,19.9,21.8,24.5,28.6];
 const audit=[];
 for(const [i,t] of times.entries()){
  await page.evaluate(t=>{window.__timelines['blumenpyramide-v2'].seek(t);return true},t);
  await page.screenshot({path:`deliverables/scene-${String(i+1).padStart(2,'0')}.jpg`,type:'jpeg',quality:90});
  audit.push(await page.evaluate(({i,t})=>{const s=document.querySelector('#s'+i);return {time:t,scene:i+1,texts:[...s.querySelectorAll('h1,.eyebrow,.note,.cta,.closing')].map(el=>{const b=el.getBoundingClientRect();return {text:el.textContent,x:b.x,y:b.y,width:b.width,height:b.height,scrollWidth:el.scrollWidth,clientWidth:el.clientWidth}})}},{i,t}));
 }
 // Verify arbitrary backwards/forwards seeks for non-linear rendering workers.
 for(const t of [29,0,15,2,26.5,8,29.5])await page.evaluate(t=>{window.__timelines['blumenpyramide-v2'].seek(t);return true},t);
 const result={errors,warnings,audit};writeFileSync('deliverables/layout-audit.json',JSON.stringify(result,null,2));console.log(JSON.stringify({errors,warnings: warnings.slice(0,12),frames:times.length}));
}finally{await browser.close()}
