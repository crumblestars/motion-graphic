import numpy as np, wave
from scipy.signal import butter,sosfilt
sr=44100; n=sr*30; beat=60/128; rng=np.random.default_rng(20261017)
mix=np.zeros((n,2)); bus=np.zeros((n,2))
def put(dest,start,x,gain=1,pan=0):
 i=int(start*sr); end=min(n,i+len(x)); amount=end-i
 if amount<=0:return
 dest[i:end,0]+=x[:amount]*gain*np.sqrt((1-pan)/2); dest[i:end,1]+=x[:amount]*gain*np.sqrt((1+pan)/2)
def hz(m):return 440*2**((m-69)/12)
def lp(x,f):return sosfilt(butter(2,f,fs=sr,output='sos'),x)
def pluck(m,length=1.4):
 t=np.arange(int(sr*length))/sr; f=hz(m)
 x=sum(np.sin(2*np.pi*f*k*t)*np.exp(-t*(3.5+k*1.8))/k**1.4 for k in range(1,7))
 return x*(1-np.exp(-t*190))
def bass(m):
 t=np.arange(int(sr*.46))/sr; f=hz(m)
 x=(np.sin(2*np.pi*f*t)+.3*np.sin(2*np.pi*2*f*t)+.12*np.sin(2*np.pi*3*f*t))
 return x*np.minimum(1,t/.012)*np.exp(-t*6)
chords=[[50,57,62,65],[46,53,58,62],[43,50,55,58],[45,52,57,61]]
for bar in range(16):
 ch=chords[bar%4]; start=bar*4*beat
 for k,m in enumerate([ch[2]+12,ch[3]+12,ch[1]+12,ch[3]+12,ch[2]+12,ch[1]+12,ch[3]+12,ch[2]+12]):
  put(bus,start+k*beat/2,pluck(m),.105 if k%2==0 else .055,(-1)**k*.4)
 t=np.arange(int(sr*2.4))/sr; env=np.minimum(1,t/.25)*np.minimum(1,(2.4-t)/.5)
 pad=sum(np.sin(2*np.pi*hz(m)*t)+.15*np.sin(2*np.pi*2*hz(m)*t) for m in ch)/4
 put(bus,start,pad*env,.11,.08*(-1)**bar)
 for k in [0,1.5,2,3.5]:put(bus,start+k*beat,bass(ch[0]-12),.35)
 # High bell phrase resolves at the end of each group.
 if bar%2==0:put(bus,start,pluck([86,89,84,85][(bar//2)%4],2),.055,-.2)
for b in range(64):
 start=b*beat; t=np.arange(int(sr*.28))/sr
 kick=np.sin(2*np.pi*(47*t+2.2*(1-np.exp(-t*34))))*np.exp(-t*17)
 click=lp(rng.normal(size=len(t)),1700)*np.exp(-t*150)
 put(mix,start,kick+.06*click,.53)
 if b%4 in [1,3]:
  t=np.arange(int(sr*.14))/sr; noise=rng.normal(size=len(t)); noisy=noise-lp(noise,1400)
  clap=(np.exp(-t*55)+.7*np.exp(-np.maximum(0,t-.013)*60)*(t>=.013)+.45*np.exp(-np.maximum(0,t-.026)*60)*(t>=.026))
  put(mix,start,noisy*clap,.048)
 for off,g in [(0,.012),(.5,.025)]:
  t=np.arange(int(sr*.09))/sr; noise=rng.normal(size=len(t)); high=noise-lp(noise,6500)
  put(mix,start+off*beat,high*np.exp(-t*75),g,(-1)**b*.35)
 # Gentle sidechain movement in the harmonic bed.
 lo=int(start*sr);hi=min(n,int((start+beat)*sr));t=np.arange(hi-lo)/sr
 bus[lo:hi]*=(.62+.38*(1-np.exp(-t*18)))[:,None]
for bar in range(1,14):
 if bar in [12,13]:continue
 center=bar*4*beat; t=np.arange(int(sr*.34))/sr
 noise=lp(rng.normal(size=len(t)),3800); env=np.sin(np.pi*np.arange(len(t))/len(t))**2
 # Airy transition sound centered on the visual handoff.
 put(mix,center-.10,noise*env,.027,(-1)**bar*.3)
# Last CTA accent.
put(bus,26.25,pluck(86,2.4),.11)
dry=bus.copy()
for sec,g in [(beat*.75,.16),(beat*1.5,.10),(beat*3,.045)]:
 d=int(sec*sr);bus[d:]+=dry[:-d,::-1]*g
mix+=bus
fadein=np.minimum(1,np.arange(n)/sr/.10);fadeout=np.minimum(1,(n-1-np.arange(n))/sr/.65)
mix=np.tanh(mix*1.1)*(fadein*fadeout)[:,None];mix*=.88/np.max(np.abs(mix))
with wave.open('assets/autumn-drive-128.wav','wb') as w:
 w.setnchannels(2);w.setsampwidth(2);w.setframerate(sr);w.writeframes((mix*32767).astype('<i2').tobytes())
print('30 s original score; 128 BPM; 64 beats; 16 bars.')
