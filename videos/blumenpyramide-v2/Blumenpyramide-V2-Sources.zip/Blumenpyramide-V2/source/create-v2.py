from pathlib import Path
import json
P=Path('.')
A='assets/bouquet-amber.png';B='assets/bouquet-bordeaux.png'
def floral(src,cls='hero',extra=''):
 return f'<div class="{cls} reveal-object" data-layout-ignore {extra}><div class="drift"><img src="{src}" alt="Herbstlicher Blumenstrauß" /></div></div>'
def lines(*parts):
 return '<h1>'+''.join(f'<span class="line {"hot" if i%2 else ""}">{part}</span>' for i,part in enumerate(parts))+'</h1>'
def head(k,*words,cls=''):
 return f'<div class="copy {cls}"><p class="eyebrow">{k}</p>{lines(*words)}<div class="short-rule"></div></div>'
def petals():
 return '<div class="petals" data-layout-ignore>'+''.join(f'<i class="petal p{j}"></i>' for j in range(7))+'</div>'
def orbit():
 return '<div class="orbit reveal-decor" data-layout-ignore><div class="orbit-rotor"><svg viewBox="0 0 1000 1000" fill="none"><ellipse cx="500" cy="500" rx="464" ry="310" transform="rotate(-25 500 500)" stroke="#e8bf73" stroke-width="1.5"/><path d="M165 820Q850 900 910 360" stroke="#db7438" stroke-width="2"/><circle cx="910" cy="360" r="11" fill="#e8bf73"/><path d="M60 500h80m-40-40v80" stroke="#e8bf73" stroke-width="2"/></svg></div></div>'
def note(s):return f'<p class="note">{s}</p>'
scenes=[]
scenes.append(('hook','push',head('BLUMENPYRAMIDE · AUTUMN EDITION','DIESER','HERBST.')+orbit()+floral(A)+note('Herbstzauber beginnt hier.')))
scenes.append(('magic','zoom',orbit()+floral(B)+head('FARBEN. BLÜTEN. GEFÜHLE.','WIRD','MAGISCH.',cls='lower')+note('Eine Saison voller Möglichkeiten.')))
scenes.append(('orange','push',head('DIE FARBEN DES HERBSTES','LEUCHTEND.','ORANGE.')+'<div class="color-disc" data-layout-ignore></div>'+floral(A)+note('Wärme, die ins Auge fällt.')))
scenes.append(('bordeaux','zoom',head('DIE FARBEN DES HERBSTES','TIEFES','BORDEAUX.')+orbit()+floral(B)+note('Samtige Töne. Starker Auftritt.')))
scenes.append(('bloom','vertical',head('UNSERE LIEBSTE JAHRESZEIT','HERBST','IN BLÜTE.')+floral(A,'hero hero-left')+floral(B,'hero hero-right')+note('Zwei Looks. Ein besonderes Gefühl.')))
scenes.append(('halloween','zoom','<img class="full-photo" src="assets/autumn-bordeaux.png" alt="Herbstblumen mit Kerze und Kürbis" data-layout-ignore/><div class="photo-veil" data-layout-ignore></div><div class="date-stamp reveal-decor" data-layout-ignore>31 / 10</div>'+head('EIN BESONDERER ANLASS','HALLOWEEN.','ABER ELEGANT.')+note('Blüten treffen Kerzenschein.')))
scenes.append(('romance','push',orbit()+floral(B)+head('DIE DUNKLE SEITE DES HERBSTES','DUNKLE','ROMANTIK.',cls='lower')+note('Bordeaux. Kupfer. Ein Hauch Magie.')))
scenes.append(('warmth','zoom',head('FÜR DEIN ZUHAUSE','WARME','MOMENTE.')+orbit()+floral(A)+note('Ein floraler Akzent für den Herbst.')))
scenes.append(('giving','push',head('FÜR EINEN LIEBLINGSMENSCHEN','ZUM','VERSCHENKEN.')+floral(B)+'<div class="gift-tag reveal-decor"><span>FÜR</span><strong>DICH.</strong><i>mit Liebe</i></div>'+note('Ein Strauß. Eine schöne Geste.')))
scenes.append(('loving','zoom','<svg class="heart reveal-decor" viewBox="0 0 1000 1000" data-layout-ignore><path d="M500 840C350 700 80 510 115 290C150 75 400 110 500 290C600 110 850 75 885 290C920 510 650 700 500 840Z" fill="none" stroke="#e8bf73" stroke-width="2"/></svg>'+floral(A)+head('ODER EINFACH FÜR DICH','ZUM','VERLIEBEN.',cls='lower')))
scenes.append(('little','vertical',head('HERBSTZAUBER IN VOLLER BLÜTE','KLEINE','MAGIE.')+'<div class="glow-disc" data-layout-ignore></div>'+floral(B)+note('Manchmal braucht es nur Blumen.')))
scenes.append(('feelings','zoom','<div class="photo-window reveal-object"><img src="assets/autumn-amber.png" alt="Dahlien und Rosen in Herbstfarben"/></div>'+head('FARBEN, DIE BERÜHREN','GROSSE','GEFÜHLE.',cls='lower')+note('Natürlich Blumenpyramide.')))
scenes.append(('discover','push',head('ENTDECKEN SIE UNSERE','HERBST','KREATIONEN.')+'<div class="product-gallery"><div class="product-card card-a reveal-object">'+floral(A,'card-flower')+'<p>WARM & LEUCHTEND</p></div><div class="product-card card-b reveal-object">'+floral(B,'card-flower')+'<p>DUNKEL & ROMANTISCH</p></div></div>'+note('Welcher Herbst-Look ist Ihrer?')))
scenes.append(('final','zoom',floral(A,'hero end-left')+floral(B,'hero end-right')+'<div class="brand-emblem reveal-decor" data-layout-ignore>B<span>✦</span></div><div class="copy endcopy"><p class="eyebrow">HERBST & HALLOWEEN</p><h1 class="wordmark"><span class="line">Blumenpyramide<span class="period">.</span></span></h1><p class="tagline">Herbstzauber in voller Blüte.</p><div class="cta">JETZT BESTELLEN <span>↗</span></div><p class="closing">Entdecken Sie unsere Herbstkreationen.</p></div>'))
css='''
@font-face{font-family:ImpactAtelier;src:url(assets/sans-bold.otf);font-weight:700}
@font-face{font-family:Quiet;src:url(assets/sans.otf)}
@font-face{font-family:Atelier;src:url(assets/serif.otf)}
@font-face{font-family:Atelier;src:url(assets/serif-italic.otf);font-style:italic}
*{margin:0;box-sizing:border-box}html,body{width:1080px;height:1920px;overflow:hidden;background:#100b0a;color:#fff1d9;font-family:Quiet,sans-serif}
#root{width:1080px;height:1920px;position:relative;overflow:hidden}.scene{position:absolute;inset:0;width:1080px;height:1920px;overflow:hidden;opacity:0;transform-origin:50% 50%}.scene:first-child{opacity:1}
.stage{position:relative;width:100%;height:100%;overflow:hidden;background:#100b0a;background-image:radial-gradient(ellipse at 68% 55%,#382015 0%,#100b0a 62%)}
.scene-content{position:relative;display:flex;flex-direction:column;gap:26px;width:100%;height:100%;padding:230px 80px 170px;overflow:hidden;box-sizing:border-box}
.copy{position:relative;display:flex;flex-direction:column;gap:28px;z-index:7;flex-shrink:0}.eyebrow{font:28px/1.4 Quiet;letter-spacing:3px;color:#e8bf73}
h1{font:700 162px/.99 ImpactAtelier,sans-serif;letter-spacing:-7px;text-transform:uppercase;max-width:930px}.line{display:block;position:relative;will-change:transform}.hot{color:#db7438}.short-rule{width:125px;height:3px;background:#e8bf73;transform-origin:left center;margin-top:12px}
.note{position:relative;z-index:8;margin-top:auto;font:32px/1.4 Quiet;color:#fff1d9;letter-spacing:.2px;max-width:920px}
.hero{position:absolute;width:1110px;height:1110px;left:10px;top:640px;z-index:5;transform-origin:50% 55%;pointer-events:none}.hero .drift{width:100%;height:100%}.hero img{width:100%;height:100%;object-fit:contain;filter:drop-shadow(0 28px 25px rgba(0,0,0,.35))}
.orbit{position:absolute;left:-35px;top:550px;width:1160px;height:1160px;z-index:2;opacity:.62}.orbit-rotor{width:100%;height:100%}.orbit svg{width:100%;height:100%}
.lower{margin-top:auto;margin-bottom:75px}.lower+.note{margin-top:0}
.petals{position:absolute;inset:0;pointer-events:none;z-index:10}.petal{position:absolute;width:34px;height:70px;background:#bd642f;border-radius:80% 10% 80% 12%;opacity:.72;box-shadow:inset 1px 0 rgba(255,241,217,.22)}.p0{left:44px;top:460px}.p1{background:#e8bf73;left:910px;top:360px;transform:rotate(70deg)}.p2{left:940px;top:1260px;width:26px;height:52px}.p3{left:95px;top:1520px;transform:rotate(-25deg)}.p4{background:#8f3e25;left:860px;top:900px;width:22px;height:44px}.p5{left:330px;top:1690px;width:17px;height:35px}.p6{left:720px;top:530px;width:16px;height:33px}
.color-disc,.glow-disc{position:absolute;width:1030px;height:1030px;border-radius:50%;background:#a64722;left:210px;top:650px;z-index:1}.glow-disc{background:radial-gradient(circle,#713b24 0%,rgba(113,59,36,0) 70%);left:30px}
#s0 .hero{top:605px;left:20px;width:1170px;height:1170px;transform:rotate(-10deg)}
#s1 .hero{top:180px;left:100px;width:1020px;height:1020px;transform:rotate(12deg)}#s1 h1{font-size:168px}#s1 .stage{background-image:radial-gradient(ellipse at 30% 38%,#4b1c29,#100b0a 65%)}
#s2 h1{font-size:151px}#s2 .hero{top:660px;left:-120px;width:1290px;height:1290px;transform:rotate(-17deg)}#s2 .note{color:#fff1d9;text-shadow:0 2px 12px #100b0a}
#s3 .stage{background:#40131e;background-image:radial-gradient(ellipse at 50% 60%,#692636,#240d14 80%)}#s3 h1{font-size:144px}#s3 .hot{color:#fff1d9}#s3 .hero{top:625px;left:30px;width:1160px;height:1160px;transform:rotate(15deg)}
#s4 h1{font-size:162px}.hero-left{width:850px;height:850px;left:-230px;top:740px;transform:rotate(-25deg)}.hero-right{width:880px;height:880px;left:420px;top:870px;transform:rotate(24deg)}#s4 .note{font-size:30px}
.full-photo{position:absolute;inset:0;width:100%;height:100%;object-fit:cover}.photo-veil{position:absolute;inset:0;background:radial-gradient(ellipse at 55% 85%,rgba(16,11,10,0),rgba(16,11,10,.88) 75%);z-index:1}#s5 h1{font-size:113px;letter-spacing:-4px;line-height:1.08}#s5 .copy{margin-top:160px}#s5 .hot{font-size:105px}.date-stamp{position:absolute;right:90px;top:210px;font:italic 68px Atelier;z-index:5;color:#e8bf73;transform:rotate(-7deg)}#s5 .note{font-family:Atelier;font-style:italic;font-size:40px}
#s6 .hero{top:180px;left:-80px;width:1220px;height:1220px;transform:rotate(-15deg)}#s6 h1{font-size:151px}#s6 .stage{background-image:radial-gradient(ellipse at 70% 30%,#49212d,#100b0a 60%)}
#s7 .hero{top:675px;left:130px;transform:rotate(20deg);width:1200px;height:1200px}#s7 h1{font-size:150px}
#s8 h1{font-size:122px;letter-spacing:-5px}#s8 .hero{top:600px;left:-90px;width:1120px;height:1120px;transform:rotate(-12deg)}.gift-tag{position:absolute;right:90px;top:1080px;width:270px;height:350px;padding:45px 35px;background:#fff1d9;color:#40131e;z-index:8;transform:rotate(12deg);box-shadow:0 25px 60px rgba(0,0,0,.4);display:flex;flex-direction:column;gap:16px}.gift-tag:before{content:'';width:17px;height:17px;border:1px solid #a87946;border-radius:50%;position:absolute;top:15px;left:125px}.gift-tag span{font:28px Quiet;letter-spacing:4px}.gift-tag strong{font:700 58px ImpactAtelier}.gift-tag i{font:italic 36px Atelier}
#s9 .stage{background:#40131e;background-image:radial-gradient(ellipse at 40% 35%,#722c38,#240e16 75%)}#s9 .hero{top:160px;left:90px;width:1040px;height:1040px;transform:rotate(10deg)}#s9 h1{font-size:136px}.heart{position:absolute;left:0;top:300px;width:1080px;height:1080px;z-index:2;opacity:.5}
#s10 h1{font-size:176px}#s10 .hero{top:680px;left:60px;width:1100px;height:1100px;transform:rotate(-8deg)}
.photo-window{position:absolute;left:-80px;top:-20px;width:1240px;height:1320px;overflow:hidden;transform:rotate(-5deg)}.photo-window img{width:100%;height:100%;object-fit:cover;object-position:50% 60%;transform:scale(1.18)}.photo-window:after{content:'';position:absolute;inset:0;background:linear-gradient(180deg,rgba(16,11,10,0),rgba(16,11,10,.1) 50%,#100b0a 100%)}#s11 h1{font-size:150px}#s11 .lower{margin-bottom:95px}
#s12 h1{font-size:138px;letter-spacing:-5px}.product-gallery{position:relative;width:100%;height:860px;display:flex;gap:28px;align-items:center;z-index:4;margin-top:20px}.product-card{position:relative;width:446px;height:710px;flex-shrink:0;border:1px solid #8c6240;border-radius:28px;background:#1d1512;box-shadow:0 35px 60px rgba(0,0,0,.4);overflow:hidden}.product-card.card-a{transform:rotate(-8deg);margin-top:-70px}.product-card.card-b{transform:rotate(8deg);margin-top:50px;background:#30141d}.card-flower{position:absolute;inset:15px -45px 100px;width:520px;height:520px;pointer-events:none}.card-flower .drift,.card-flower img{width:100%;height:100%;object-fit:contain}.product-card p{position:absolute;left:24px;right:24px;bottom:38px;text-align:center;font:24px Quiet;letter-spacing:2px;color:#fff1d9}.product-card:after{content:'↗';position:absolute;bottom:94px;right:30px;font:36px Quiet;color:#e8bf73}#s12 .note{text-align:center;width:100%;font-size:31px}
#s13 .scene-content{align-items:center;justify-content:center;padding:200px 70px 170px;gap:40px}#s13 .stage{background-image:radial-gradient(ellipse at 50% 40%,#45291b,#100b0a 66%)}.end-left{width:770px;height:770px;left:-185px;top:70px;transform:rotate(-26deg)}.end-right{width:760px;height:760px;left:510px;top:110px;transform:rotate(28deg)}.endcopy{align-items:center;text-align:center;margin-top:650px;gap:34px}.wordmark{font:90px/1.15 Atelier;letter-spacing:-4px;text-transform:none;white-space:nowrap;max-width:960px}.wordmark .period{color:#e8bf73}.tagline{font:italic 48px/1.25 Atelier;position:relative}.cta{display:flex;align-items:center;gap:65px;padding:34px 48px;background:#db7438;color:#100b0a;font:700 41px ImpactAtelier;letter-spacing:.5px;margin-top:35px;border-radius:4px;box-shadow:0 18px 40px rgba(0,0,0,.35)}.cta span{font:54px Quiet;line-height:1}.closing{font:30px/1.4 Quiet;margin-top:14px;max-width:900px}.brand-emblem{position:absolute;left:468px;top:570px;z-index:9;width:145px;height:145px;display:flex;align-items:center;justify-content:center;border:1px solid #e8bf73;border-radius:50%;font:88px Atelier;color:#fff1d9;background:rgba(16,11,10,.65)}.brand-emblem span{font:30px Quiet;position:absolute;right:-10px;top:-10px;color:#e8bf73}
.brandbar{position:absolute;top:70px;left:80px;right:80px;z-index:30;display:flex;align-items:center;justify-content:space-between;pointer-events:none}.brandbar .brand{font:35px Atelier;letter-spacing:-.6px}.brandbar .edition{font:21px Quiet;letter-spacing:3px;color:#e8bf73}.progress{position:absolute;left:80px;bottom:85px;width:920px;height:2px;background:#5f4231;z-index:30}.progress .fill{height:100%;width:100%;transform-origin:left center;background:#e8bf73}.frame{position:absolute;inset:34px;border:1px solid rgba(232,191,115,.14);pointer-events:none;z-index:29}.grain{position:absolute;inset:0;background:url(assets/grain.svg);opacity:.026;z-index:28;pointer-events:none}
'''
starts=[i*1.875 for i in range(12)]+[22.5,26.25]
# Source-compatible Theatre state: ornament path is sampled into deterministic GSAP visual tweens.
state={'definitionVersion':'0.4.0','revisionHistory':['blumen-drive-v2'],'sheetsById':{'Botanical':{'staticOverrides':{'byObject':{}},'sequence':{'type':'PositionalSequence','length':30,'subUnitsPerUnit':60,'tracksByObject':{'Orbit':{'trackIdByPropPath':{'["angle"]':'r'},'trackData':{'r':{'type':'BasicKeyframedTrack','keyframes':{'byId':{},'allIds':{}}}}}}}}}}
k=state['sheetsById']['Botanical']['sequence']['tracksByObject']['Orbit']['trackData']['r']['keyframes']
for i,(t,v) in enumerate([(0,-15),(7.5,22),(15,-12),(22.5,25),(30,0)]):
 key={'id':f'k{i}','position':t,'value':v,'connectedRight':True,'handles':[.5,1,.5,0]};k['byId'][key['id']]=key;k['allIds'][key['id']]=True
js='''
window.__timelines=window.__timelines||{};
const starts=STARTS, transitions=TRANSITIONS;
const project=Theatre.getProject('Blumenpyramide Drive V2',{state:STATE});
const sheet=project.sheet('Botanical'), ornament=sheet.object('Orbit',{angle:0});
const orbitSamples=[];
for(let t=0;t<=30;t+=.5){sheet.sequence.position=t;orbitSamples.push(ornament.value.angle)}
const tl=gsap.timeline({paused:true});
const q=(s)=>document.querySelectorAll(s);
const entry=(selector,vars,time)=>{if(q(selector).length)tl.from(selector,vars,time)};
for(let i=0;i<14;i++){
 const s='#s'+i, at=starts[i], end=i<13?starts[i+1]:30;
 const base=at+(i===0?.12:.18);
 if(i>0){
  const old='#s'+(i-1), typ=transitions[i];
  tl.set(s,{opacity:1},at);
  if(typ==='push'){
   const dir=i%2===0?1:-1;
   tl.fromTo(s+' .stage',{x:dir*1080},{x:0,duration:.40,ease:'power3.inOut',immediateRender:false},at);
   tl.to(old+' .stage',{x:-dir*1080,duration:.40,ease:'power3.inOut'},at);
  }else if(typ==='vertical'){
   tl.fromTo(s+' .stage',{y:1920},{y:0,duration:.42,ease:'power3.inOut',immediateRender:false},at);
   tl.to(old+' .stage',{y:-1920,duration:.42,ease:'power3.inOut'},at);
  }else{
   tl.fromTo(s+' .stage',{scale:.82,opacity:0},{scale:1,opacity:1,duration:.38,ease:'power3.out',immediateRender:false},at+.035);
   tl.to(old+' .stage',{scale:1.24,opacity:0,duration:.38,ease:'power2.in'},at);
  }
  tl.set(old,{opacity:0},at+.43);
 }
 entry(s+' .eyebrow',{x:-35,opacity:0,duration:.36,ease:'power2.out'},base);
 entry(s+' h1>.line',{y:i%2===0?62:-56,opacity:0,duration:.48,stagger:.07,ease:'expo.out'},base+.055);
 entry(s+' .short-rule',{scaleX:0,duration:.6,ease:'sine.out'},base+.12);
 entry(s+' .note',{y:20,opacity:0,duration:.4,ease:'power1.out'},base+.32);
 entry(s+' .reveal-decor',{scale:.78,opacity:0,duration:.57,ease:'power3.out'},base+.05);
 q(s+' .reveal-object').forEach((el,j)=>{
  const sign=(i+j)%2?1:-1;
  // Entrance, drift and scene transition each have their own transform wrapper.
  tl.from(el,{x:sign*145,y:i%2?65:110,scale:.82,opacity:0,duration:i===12?.67:.60,ease:'power3.out'},base+j*.065);
 });
 q(s+' .drift').forEach((el,j)=>{
  const sign=(i+j)%2?1:-1;
  tl.fromTo(el,{x:-sign*35,y:20,rotation:-sign*4,scale:1.02},{x:sign*38,y:-24,rotation:sign*4,scale:1.08,duration:end-at+.35,ease:'sine.inOut',immediateRender:false},at+.08);
 });
 q(s+' .petal').forEach((el,j)=>{
  const sign=j%2?1:-1;
  tl.fromTo(el,{x:-sign*45,y:-30,rotation:j*37,opacity:0},{x:sign*80,y:120+j*10,rotation:j*37+sign*100,opacity:.7,duration:end-at+.2,ease:'sine.inOut',immediateRender:false},at+.06+j*.035);
 });
 if(i===5)tl.fromTo(s+' .full-photo',{scale:1.08,y:35},{scale:1.16,y:-40,duration:2.25,ease:'sine.inOut',immediateRender:false},at);
 if(i===11)tl.fromTo(s+' .photo-window img',{scale:1.25,y:10},{scale:1.38,y:-35,duration:2.25,ease:'sine.inOut',immediateRender:false},at);
 if(i===13){
  entry(s+' .tagline',{x:30,opacity:0,duration:.6,ease:'sine.out'},at+.55);
  entry(s+' .cta',{y:45,scale:.95,opacity:0,duration:.55,ease:'power3.out'},at+.70);
  entry(s+' .closing',{opacity:0,duration:.45,ease:'power1.out'},at+.85);
 }
}
for(let k=1;k<orbitSamples.length;k++)tl.to('.orbit-rotor',{rotation:orbitSamples[k],duration:.5,ease:'none'},(k-1)*.5);
tl.from('.brandbar',{opacity:0,y:-15,duration:.45,ease:'power2.out'},.13);
tl.from('.frame',{opacity:0,duration:.6,ease:'sine.out'},.1);
tl.fromTo('.progress .fill',{scaleX:0},{scaleX:1,duration:30,ease:'none'},0);
window.__timelines['blumenpyramide-v2']=tl;
'''.replace('STARTS',json.dumps(starts)).replace('TRANSITIONS',json.dumps([x[1] for x in scenes])).replace('STATE',json.dumps(state))
html='<!doctype html><html lang="de"><head><meta charset="UTF-8"><title>Blumenpyramide — Autumn Drive V2</title><script src="assets/gsap.min.js"></script><script src="assets/theatre-core.js"></script><style>'+css+'</style></head><body><div id="root" data-composition-id="blumenpyramide-v2" data-start="0" data-duration="30" data-width="1080" data-height="1920" data-fps="60">'
for i,(name,typ,content) in enumerate(scenes):
 html+=f'<section id="s{i}" class="scene {name}" style="z-index:{i+1}" data-scene-name="{name}"><div class="stage"><div class="scene-content">'+content+petals()+'</div></div></section>'
html+='<div class="brandbar"><span class="brand">Blumenpyramide.</span><span class="edition">HERBST / HALLOWEEN</span></div><div class="frame" data-layout-ignore></div><div class="grain" data-layout-ignore></div><div class="progress" data-layout-ignore><div class="fill"></div></div><audio id="music" src="assets/autumn-drive-128.wav" data-start="0" data-duration="30" data-track-index="20" data-volume="0.9"></audio></div><script>'+js+'</script></body></html>'
P.joinpath('index.html').write_text(html)
P.joinpath('meta.json').write_text(json.dumps({'name':'Blumenpyramide — Autumn Drive V2','description':'14 kinetic scenes, 30 seconds, 128 BPM, portrait 60 fps'},ensure_ascii=False))
P.joinpath('source/theatre-state.json').write_text(json.dumps(state,indent=2))
P.joinpath('source/edit-map.json').write_text(json.dumps([{'scene':i+1,'name':name,'start':starts[i],'end':starts[i+1] if i<13 else 30,'transition':typ} for i,(name,typ,_) in enumerate(scenes)],indent=2))
print('Authored 14 scenes / 30 seconds / 128 BPM / 1080x1920 / 60 fps')
