## Style Prompt
A kinetic florist campaign inspired by the user's 61-second black-and-gold motion-design reference: big bold German words, continuous tracking movement, swooping botanical objects, floating product cards, rapid seamless pushes and zoom-through transitions. Adapted to autumn flowers and sophisticated Halloween; no literal software dashboards. Rich burnt orange, velvet burgundy, warm black, cream and restrained gold. Fourteen distinct sequences in 30 seconds, 128 BPM, 60 fps, vertical 9:16.
## Colors
- #100b0a : warm black
- #40131e : deep burgundy
- #db7438 : burnt orange
- #fff1d9 : warm ivory
- #e8bf73 : golden accent
## Typography
Nimbus Sans Bold: assertive short uppercase statements, 100–170 px. P052 Italic: occasional human floral accent. Nimbus Sans Regular: labels 28–34 px. No more than two text zones per scene. Maximum 2–5 headline words per 1.875-second beat group.
## Motion
128 BPM, one beat = 0.46875 s. Fourteen scenes: twelve groups of four beats, then an eight-beat product invitation and eight-beat CTA. Primary transition: 0.32-second pushes/zoom-throughs; accents: diagonal flower-mask reveal and photo focus pull. Entrance duration 0.38–0.7 s. Every bouquet has continuous smooth translation, rotation or camera tracking. Petals and leaves move along curved paths. Final CTA held for at least 2.4 s.
## What NOT to Do
No slow slideshow, no cartoon Halloween, no strobing or random glitches, no complex 3D, no invented prices or stock guarantees, no barely legible microtext. Generated bouquet visuals do not claim to be verified catalog inventory. The user reference sets motion energy, not brand identity or exact content.
