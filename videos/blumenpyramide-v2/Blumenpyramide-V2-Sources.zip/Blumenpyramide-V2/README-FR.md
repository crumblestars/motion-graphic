# Blumenpyramide V2 — Autumn Drive

Nouvelle publicité de 30 secondes inspirée du rythme et des mouvements de la vidéo de référence fournie : 14 séquences, typographie forte, bouquets détourés en mouvement, transitions par déplacement et zoom, pétales mobiles, musique originale à 128 BPM. Format 9:16, 1080 × 1920, 60 images/seconde. Textes en allemand.

La première version reste conservée séparément. La V2 utilise deux nouveaux bouquets détourés et les photographies d'automne créées pour le concept. L'image de référence et sa bande sonore ne sont pas réutilisées dans la publicité.

## Fichiers

- `deliverables/Blumenpyramide-V2-Dynamique-HD.mp4` : master HyperFrames.
- `deliverables/Blumenpyramide-V2-Dynamique-leger.mp4` : copie 720 × 1280, 60 images/seconde.
- `index.html` : composition éditable HyperFrames, avec tous ses assets locaux.
- `assets/autumn-drive-128.wav` : musique originale stéréo de 30 secondes.
- `source/edit-map.json` : découpage et transitions.
- `source/create-v2.py` et `source/music-v2.py` : génération du HTML et de la musique.
- `source/theatre-state.json` : courbes du mouvement orbital.
- `after-effects/Blumenpyramide-V2.jsx` : reconstruction sur calques modifiables dans After Effects.

## Ouvrir dans After Effects

Installer les polices OTF du dossier `assets`. Décompresser tout le dossier. Dans Adobe After Effects : **Fichier → Scripts → Exécuter le fichier de script**, puis choisir `after-effects/Blumenpyramide-V2.jsx`. Le script crée des compositions dans le projet courant ; il n'écrase aucun projet et ne l'enregistre pas automatiquement. Enregistrer ensuite sous `.aep`.

After Effects n'est pas disponible dans l'environnement : le script a passé un contrôle de syntaxe JavaScript, mais son exécution dans Adobe n'a pas été vérifiée. Cette reconstruction peut différer du rendu HTML, notamment sur les dégradés, les ornements et certains détails des calques. Le MP4 HyperFrames reste le master de référence ; aucun `.aep` natif n'est livré.

## Modifier et rendre avec HyperFrames

Node.js >= 22 et FFmpeg. Exécuter `npm ci` dans ce dossier, puis `npm run dev` pour prévisualiser. Contrôles : `npm run check`. Rendu : `npm run render -- --fps 60 --quality high --output deliverables/Blumenpyramide-V2-Dynamique-HD.mp4`.

Dans la machine cloud de production, le CLI est exécuté avec `npm --cache /workspace/.npm-cache`, et `HYPERFRAMES_BROWSER_PATH=/usr/bin/chromium`. En local, utiliser le navigateur géré par HyperFrames ou configurer son chemin.

`python source/create-v2.py` régénère le HTML. `python source/music-v2.py` nécessite NumPy et SciPy. `node source/build-theatre.mjs` recompile le moteur fourni dans `assets/theatre-core.js` depuis les sources Theatre.js incluses. Les scripts de capture et d'export de disposition utilisent un serveur local au port 9042 et Chromium ; ils ne sont pas nécessaires pour lire le MP4.

## Validation et provenance

Le contrôle HyperFrames a réussi : zéro erreur JavaScript, zéro erreur de disposition, zéro erreur de mouvement ; 32/32 contrôles de contraste WCAG AA réussis. Les deux avertissements de médias concernent la réutilisation intentionnelle des mêmes assets dans plusieurs scènes. Les informations de débordement ponctuelles correspondent aux scènes qui glissent hors champ pendant les transitions. Quatorze cadrages ont été inspectés ; des sauts avant/arrière ont aussi été vérifiés.

Les bouquets sont des visuels générés pour ce concept ; ils ne constituent pas un inventaire produit vérifié. Aucun tarif, délai ni promesse de disponibilité n'est inventé. La typographie du nom et le monogramme sont une interprétation automnale de la marque.

Theatre.js a été compilé depuis l'archive `theatre-main.zip` fournie par l'utilisateur ; ses sources et sa licence Apache 2.0 sont incluses. Le Studio AGPL n'est pas utilisé. Les deux archives Remotion de plus de 32 Mo n'ont pas pu être transférées dans l'environnement. Les polices URW Base35 et leur licence proviennent du système. La musique a été composée et synthétisée pour la V2, sans extrait musical tiers.
