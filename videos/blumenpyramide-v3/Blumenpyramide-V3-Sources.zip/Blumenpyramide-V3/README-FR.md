# Blumenpyramide V3 — Film

Refonte à partir de véritables séquences vidéo de fleurs qui s'ouvrent, avec vingt séquences en trente secondes, variations de vitesse dans les plans, typographie Anton et transitions WebGL. Film livré en 9:16, 720 × 1280, 60 images/seconde ; composition modifiable de 1080 × 1920. Musique électronique originale à 140 BPM.

La V3 écarte les bouquets photographiques détourés, les pétales décoratifs, le cadre et le bandeau permanent des versions précédentes. Les plans macro, les cartes typographiques et les passages où la vidéo remplit les lettres sont composés selon le contenu du plan.

## Bibliothèques réellement utilisées

- **Remotion 4.0.536**, `@remotion/transitions` et `@remotion/motion-blur` : montage déterministe, décodage des plans, transitions et flou de mouvement de la typographie.
- **GL Transitions** : le shader crosswarp de Eke Péter, repris par la présentation Remotion, est issu de ce catalogue MIT. Référence GitHub `gre/gl-transitions`, révision `fc3c99ab8c21575e63a85d11c773db3b5b5da42c`.
- **lifeprompt-team/remotion-scenes**, sous MIT : la révélation des caractères par masques est adaptée de `TextMaskReveal`. Révision `02c7a84241da7010b5f59c420b0110aafd1d6f0d`.
- **HyperFrames** : composition de lecture/livraison du film final fournie dans `index.html`.

Les licences des logiciels et des polices sont conservées dans `licenses/`. La licence Remotion prévoit notamment une utilisation gratuite pour les individus et les entreprises de trois employés au maximum ; les autres organisations doivent consulter les conditions de licence incluses.

## Fichiers et modification

`src/index.tsx` contient le montage, les vingt séquences, les textes et les paramètres de transition. `public/assets` contient les sept extraits vidéo préparés, la musique et les polices. `research/footage-map.json` conserve les timecodes d'origine et les modifications de vitesse. `MEDIA-CREDITS.md` documente les sources réelles et les crédits à conserver.

Prérequis vérifiés : Node 24.19.0, FFmpeg 7.1.5 et Chromium 154.0.8037.57. Installation : `npm ci`. Contrôle TypeScript : `npx tsc --noEmit`. Rendu sur la machine de production : `node research/render-v3.mjs`. Images de contrôle : `node research/render-v3.mjs --stills`. Le script utilise Chromium installé dans `/usr/bin/chromium` et le rendu WebGL logiciel. Le navigateur est lancé par Remotion avec la fonctionnalité CanvasDrawElement nécessaire aux transitions.

Les clips préparés sont inclus : leur régénération n'est pas requise pour modifier les textes ou rendre le film. Pour régénérer les clips, il faut replacer la vidéo d'origine au chemin indiqué dans `research/prepare-footage.py`, puis exécuter ce script avec FFmpeg. Le remappage temporel accélère le début et la fin de chaque ouverture et ralentit son milieu.

Adobe After Effects n'est pas installé ici. Les sources modifiables livrées sont celles de Remotion ; aucun projet `.aep` natif n'est prétendu.

## Médias et limites

Les fleurs sont des séquences génériques sous crédits Creative Commons, sélectionnées sur GitHub. Elles ne représentent pas un catalogue vérifié de Blumenpyramide. Les prix, stocks et délais ne sont pas inventés. La résolution d'origine est 720p ; voir `MEDIA-CREDITS.md`.

L'accès à Swishy, Pexels et Mixkit est bloqué par le réseau de la session. Les domaines nécessaires sont enregistrés dans le brouillon de configuration, mais cela ne prouve pas qu'ils sont accessibles. Les autres plugins cités par l'utilisateur ne sont pas activés dans cette session ; leur utilisation n'est pas revendiquée.

## Contrôles de livraison

Les deux MP4 sont contrôlés par FFprobe et décodés intégralement avec FFmpeg : 30 secondes, 1800 images, 60 images/seconde, H.264 et son AAC stéréo. `deliverables/VALIDATION.json` conserve les métadonnées et les empreintes SHA-256. Les images du storyboard sont extraites du film livré.

Le rendu utilise un export à 720 × 1280 pour limiter le temps de calcul des transitions WebGL sur le processeur de cette machine. La définition de composition reste 1080 × 1920 dans les sources ; le paramètre `scale: 2/3` dans le script de rendu règle la définition de sortie.
