## Intent
V3 replaces the previous moving bouquet photographs with actual time-lapse video, bold editorial typography and a continuous cinematic edit. The user's TikTok/LEMONADS reference sets the pacing and crafted transitions. No reused V1/V2 bouquet imagery, no floating petals, no decorative frame, no persistent brand header, no fake product UI or invented price.
## Color
Warm black #090806, parchment #f8efd9, burnt orange #f16c2e, oxblood #6a142a. Gold #dcb66c only on the closing identity. Color grading preserves natural footage detail.
## Type
Anton for decisive German display words; Nimbus Sans for compact labels; P052 for the closing Blumenpyramide wordmark. Main text 120–240 px, labels 30–40 px. Statements appear as single phrases, not repeated two-line slide templates.
## Editorial structure
30 seconds, 1080×1920, 60 fps. Real flower-opening footage in macro, integrated cinematic zooms, blur-slide and crosswarp transitions, short typographic bridges. Strong 0–3 second hook, builds through warm/orange and dark/romantic flower sequences, Halloween identity, emotional invitation, last 3 seconds for brand and order CTA. No passive Ken Burns frames.
## Motion
Fast but eased: 6–16 frame transitions, per-shot speed ramping of real footage, match cuts on flower centers, type reveals on music transients. Alternating full-screen macro, quiet black negative space and high-contrast orange type. Every layout is designed around its shot. No simulated shake and no random glitch.
## Asset provenance
GitHub research includes gre/gl-transitions (MIT), lifeprompt-team/remotion-scenes (MIT), remotion-dev/remotion (Remotion license), joefhall/blooming-data (CC BY 4.0; original Creative Commons video credits retained), and mdn/interactive-examples CC0 media. Swishy, Pexels and Mixkit are currently network-blocked; access requirements are saved, not claimed as used.
