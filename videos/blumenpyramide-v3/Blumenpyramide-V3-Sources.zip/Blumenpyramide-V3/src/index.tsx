import React,{useEffect,useState} from 'react';
import {AbsoluteFill,Audio,Composition,OffthreadVideo,registerRoot,staticFile,useCurrentFrame,useVideoConfig,interpolate,spring,delayRender,continueRender,Easing} from 'remotion';
import {TransitionSeries,linearTiming,springTiming} from '@remotion/transitions';
import {crosswarp} from '@remotion/transitions/crosswarp';
import {crossZoom} from '@remotion/transitions/cross-zoom';
import {blurSlide} from '@remotion/transitions/blur-slide';
import {CameraMotionBlur} from '@remotion/motion-blur';

const C={black:'#090806',cream:'#f8efd9',orange:'#f16c2e',wine:'#6a142a',gold:'#dcb66c'};
const FPS=60,BPM=140;
const at=(beat:number)=>Math.round(beat*FPS*60/BPM);
const FONT=`@font-face{font-family:Anton;src:url('${staticFile('assets/Anton-Regular.ttf')}')}@font-face{font-family:Quiet;src:url('${staticFile('assets/sans.otf')}')}@font-face{font-family:Atelier;src:url('${staticFile('assets/serif.otf')}')}*{box-sizing:border-box}`;

type Shot={start:number;end:number;kind:string;clip:string;words?:string[];size?:number;anchor?:'top'|'center'|'bottom';tone?:'dark'|'orange'|'cream';kicker?:string;transition:'warp'|'zoom'|'blur'|'burn';offset?:number};
export const shots:Shot[]=[
 {start:0,end:4,kind:'macro',clip:'red',words:['HERBST.'],size:258,anchor:'center',kicker:'BLUMENPYRAMIDE',transition:'zoom',offset:.4},
 {start:4,end:6,kind:'type',clip:'amber',words:['MIT'],size:340,tone:'orange',transition:'warp'},
 {start:6,end:10,kind:'bloom',clip:'amber',words:['CHARAKTER.'],size:192,anchor:'bottom',transition:'blur',offset:.2},
 {start:10,end:14,kind:'split',clip:'peach',words:['LEUCHTEND.'],size:178,anchor:'top',kicker:'FARBEN DES HERBSTES',transition:'zoom'},
 {start:14,end:16,kind:'type',clip:'golden',words:['WARM.'],size:290,tone:'cream',transition:'warp'},
 {start:16,end:20,kind:'macro',clip:'garden',words:['VOLLER','LEBEN.'],size:212,anchor:'bottom',transition:'blur'},
 {start:20,end:22,kind:'type',clip:'red',words:['DUNKEL.'],size:250,tone:'dark',transition:'warp'},
 {start:22,end:24,kind:'macro',clip:'peach',words:['EDEL.'],size:292,anchor:'center',transition:'zoom',offset:.75},
 {start:24,end:28,kind:'bloom',clip:'red',words:['ZUM','VERLIEBEN.'],size:175,anchor:'top',transition:'burn',offset:.3},
 {start:28,end:32,kind:'date',clip:'red',words:['HALLOWEEN'],size:166,tone:'orange',transition:'warp'},
 {start:32,end:36,kind:'macro',clip:'red',words:['IN VOLLER','BLÜTE.'],size:188,anchor:'bottom',transition:'zoom',offset:1.1},
 {start:36,end:38,kind:'pure',clip:'gold',transition:'blur',offset:1},
 {start:38,end:42,kind:'split',clip:'golden',words:['FÜR DEIN','ZUHAUSE.'],size:188,anchor:'top',transition:'warp',kicker:'DER HERBST ZIEHT EIN'},
 {start:42,end:44,kind:'type',clip:'red',words:['FÜR DICH.'],size:215,tone:'orange',transition:'zoom'},
 {start:44,end:48,kind:'bloom',clip:'peach',words:['ZUM','VERSCHENKEN.'],size:158,anchor:'bottom',transition:'blur'},
 {start:48,end:52,kind:'cutout',clip:'pink',words:['BLÜTE'],size:360,tone:'cream',transition:'warp'},
 {start:52,end:56,kind:'triptych',clip:'amber',words:['UNSERE','HERBSTKREATIONEN.'],size:110,anchor:'top',kicker:'ENTDECKEN SIE',transition:'zoom'},
 {start:56,end:60,kind:'macro',clip:'golden',words:['JETZT','ENTDECKEN.'],size:200,anchor:'center',transition:'blur',offset:.7},
 {start:60,end:63,kind:'signature',clip:'red',transition:'warp',offset:.5},
 {start:63,end:70,kind:'final',clip:'peach',transition:'warp',offset:.3},
];
const transFrames=(i:number)=>shots[i].transition==='burn'?12:shots[i].transition==='blur'?14:12;
const easeOut=Easing.out(Easing.cubic);

// Character mask reveal adapted from lifeprompt-team/remotion-scenes TextMaskReveal (MIT).
const MaskWord:React.FC<{text:string;size:number;color:string;delay?:number;align?:'left'|'center'}>=({text,size,color,delay=0,align='left'})=>{
 const f=useCurrentFrame(),{fps}=useVideoConfig();
 return <div style={{display:'flex',justifyContent:align==='center'?'center':'flex-start',fontFamily:'Anton',fontSize:size,lineHeight:1.05,color,whiteSpace:'nowrap',letterSpacing:-size*.017}}>{[...text].map((ch,i)=>{
  const p=spring({frame:f-delay-i*.64,fps,config:{damping:29,stiffness:290,mass:.65}});
  return <span key={i} style={{display:'inline-block',overflow:'hidden',paddingBottom:size*.08,marginBottom:-size*.08}}><span style={{display:'inline-block',transform:`translateY(${(1-p)*112}%) rotate(${(1-p)*7}deg)`,opacity:Math.min(1,p*2)}}>{ch===' '?'\u00a0':ch}</span></span>;
 })}</div>;
};
const Head:React.FC<{s:Shot;center?:boolean}>=({s,center=false})=>{
 const f=useCurrentFrame();
 const top=s.anchor==='top'?220:s.anchor==='bottom'?1260:700;
 return <AbsoluteFill style={{padding:'0 76px',justifyContent:'flex-start',alignItems:center?'center':'flex-start',paddingTop:top,pointerEvents:'none'}}>
  {s.kicker&&<div style={{font:'32px Quiet',letterSpacing:4,color:C.cream,opacity:interpolate(f,[5,18],[0,1],{extrapolateLeft:'clamp',extrapolateRight:'clamp'}),marginBottom:30}}>{s.kicker}</div>}
  <div style={{position:'relative',width:'100%',height:560}}>{f<30?<CameraMotionBlur samples={3} shutterAngle={160}><AbsoluteFill>{(s.words||[]).map((w,i)=><MaskWord key={w} text={w} size={s.size||180} color={i%2?C.orange:C.cream} delay={5+i*3} align={center?'center':'left'}/>)}</AbsoluteFill></CameraMotionBlur>:<AbsoluteFill>{(s.words||[]).map((w,i)=><MaskWord key={w} text={w} size={s.size||180} color={i%2?C.orange:C.cream} delay={5+i*3} align={center?'center':'left'}/>)}</AbsoluteFill>}</div>
 </AbsoluteFill>;
};
const Footage:React.FC<{clip:string;offset?:number;style?:React.CSSProperties;dim?:number;contain?:boolean;muteTone?:boolean}>=({clip,offset=0,style={},dim=0,contain=false,muteTone=false})=>{
 return <AbsoluteFill style={{...style,overflow:'hidden'}}><OffthreadVideo src={staticFile(`assets/bloom-${clip}.mp4`)} trimBefore={Math.round(offset*60)} muted style={{width:'100%',height:'100%',objectFit:contain?'contain':'cover',filter:muteTone?'saturate(.72) contrast(1.1)':'none'}}/>{dim>0&&<AbsoluteFill style={{background:C.black,opacity:dim}}/>}</AbsoluteFill>;
};
const ShotScene:React.FC<{shot:Shot;index:number}>=({shot:s,index})=>{
 const f=useCurrentFrame(),{fps}=useVideoConfig();
 const bg=s.tone==='orange'?C.orange:s.tone==='cream'?C.cream:C.black;
 const dur=at(s.end)-at(s.start)+14;
 const roll=spring({frame:f-4,fps,config:{damping:26,stiffness:240}});
 const h=interpolate(f,[0,dur],[0,1],{extrapolateRight:'clamp'});
 if(s.kind==='type')return <AbsoluteFill style={{background:bg,justifyContent:'center',alignItems:'center',overflow:'hidden'}}>
  <div style={{position:'absolute',left:-40,right:-40,top:300,transform:`translateX(${interpolate(f,[0,dur],[-80,80])}px)`,color:bg===C.black?'#3c2820':bg===C.orange?'#cb4920':'#ddcdb8',font:'260px Anton',letterSpacing:-8,whiteSpace:'nowrap'}}>{s.words?.[0]} {s.words?.[0]}</div>
  <div style={{position:'relative',transform:`scale(${1+(1-roll)*.20})`}}><MaskWord text={s.words?.[0]||''} size={s.size||260} color={bg===C.black?C.cream:C.black} delay={3} align="center"/></div>
 </AbsoluteFill>;
 if(s.kind==='date')return <AbsoluteFill style={{background:C.black,overflow:'hidden',alignItems:'center'}}>
  <Footage clip="red" offset={.2} dim={.5}/>
  <div style={{position:'absolute',top:430,color:C.orange,font:'340px Anton',letterSpacing:-8,lineHeight:1,transform:`translateY(${(1-roll)*80}px)`}}>31.10</div>
  <div style={{position:'absolute',top:870}}><MaskWord text="HALLOWEEN" size={166} color={C.cream} delay={6} align="center"/></div>
  <div style={{position:'absolute',top:1150,font:'40px Quiet',letterSpacing:8,color:C.cream,opacity:roll}}>IN VOLLER BLÜTE</div>
 </AbsoluteFill>;
 if(s.kind==='cutout')return <AbsoluteFill style={{background:C.cream,justifyContent:'center',alignItems:'center'}}>
  <div style={{position:'absolute',top:250,left:80,font:'32px Quiet',letterSpacing:6,color:C.black}}>HERBSTZAUBER</div>
  <svg width="1080" height="1920" style={{position:'absolute'}}><defs><clipPath id={'bloom-type-'+index}><text x="540" y="1080" textAnchor="middle" fontFamily="Anton" fontSize="360" letterSpacing="-8">BLÜTE</text></clipPath></defs></svg>
  <div style={{position:'absolute',inset:0,clipPath:`url(#bloom-type-${index})`,transform:`translateY(${(1-roll)*60}px)`}}><Footage clip="pink" offset={.4} /></div>
  <div style={{position:'absolute',bottom:300,font:'38px Quiet',color:C.black}}>DIE SCHÖNSTE SPRACHE DES HERBSTES.</div>
 </AbsoluteFill>;
 if(s.kind==='signature')return <AbsoluteFill style={{background:C.black,alignItems:'center',justifyContent:'center'}}>
  <Footage clip="red" offset={s.offset} dim={.5}/>
  <svg width="800" height="700" viewBox="0 0 800 700" style={{position:'absolute',top:500}}><text x="400" y="530" textAnchor="middle" fontFamily="Atelier" fontSize="590" fill="none" stroke={C.gold} strokeWidth="2" strokeDasharray="2300" strokeDashoffset={2300*(1-Math.min(1,roll))}>B</text><text x="400" y="530" textAnchor="middle" fontFamily="Atelier" fontSize="590" fill={C.cream} opacity={interpolate(f,[18,37],[0,1],{extrapolateLeft:'clamp',extrapolateRight:'clamp'})}>B</text></svg>
 </AbsoluteFill>;
 if(s.kind==='final')return <AbsoluteFill style={{background:C.black,justifyContent:'center',alignItems:'center'}}>
  <Footage clip="peach" offset={s.offset} dim={.7}/>
  <div style={{position:'relative',textAlign:'center',padding:'0 64px',transform:`translateY(${(1-roll)*45}px)`,opacity:Math.min(1,roll*2)}}>
   <div style={{font:'30px Quiet',letterSpacing:6,color:C.gold,marginBottom:45}}>HERBST & HALLOWEEN</div>
   <div style={{font:'92px Atelier',letterSpacing:-3,color:C.cream,whiteSpace:'nowrap'}}>Blumenpyramide<span style={{color:C.gold}}>.</span></div>
   <div style={{font:'37px Quiet',color:C.cream,marginTop:45}}>Herbstzauber in voller Blüte.</div>
   <div style={{display:'flex',alignItems:'center',justifyContent:'center',gap:55,background:C.orange,color:C.black,margin:'90px auto 0',padding:'34px 45px',width:670,font:'44px Anton',transform:`translateY(${interpolate(f,[10,30],[55,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'})}px)`,opacity:interpolate(f,[10,25],[0,1],{extrapolateLeft:'clamp',extrapolateRight:'clamp'})}}>JETZT BESTELLEN <span style={{font:'58px Quiet'}}>↗</span></div>
  </div>
 </AbsoluteFill>;
 if(s.kind==='triptych')return <AbsoluteFill style={{background:C.black}}>
  <div style={{position:'absolute',left:0,right:0,top:660,height:980,display:'flex',gap:12,transform:`translateY(${(1-roll)*100}px)`}}>{['amber','red','golden'].map((name,j)=><div key={name} style={{position:'relative',width:352,height:980,overflow:'hidden',marginTop:j===1?100:0}}><Footage clip={name} offset={j*.2}/></div>)}</div>
  <Head s={s}/>
 </AbsoluteFill>;
 if(s.kind==='split')return <AbsoluteFill style={{background:C.black,overflow:'hidden'}}>
  <div style={{position:'absolute',left:110,top:660,width:1120,height:1120,transform:`translateX(${(1-roll)*200}px)`}}><Footage clip={s.clip} offset={s.offset}/></div>
  <div style={{position:'absolute',left:0,top:500,bottom:0,width:20,background:C.orange,transform:`scaleY(${roll})`,transformOrigin:'top'}}/>
  <Head s={s}/>
 </AbsoluteFill>;
 if(s.kind==='bloom')return <AbsoluteFill style={{background:C.black,overflow:'hidden'}}>
  <Footage clip={s.clip} offset={s.offset} style={{top:s.anchor==='top'?600:130,height:1200,left:-90,width:1260}}/>
  <Head s={s}/>
 </AbsoluteFill>;
 return <AbsoluteFill style={{background:C.black}}><Footage clip={s.clip} offset={s.offset} dim={s.kind==='pure'?0:index===17?.64:.23}/>{s.kind!=='pure'&&<Head s={s} center={s.anchor==='center'}/>}</AbsoluteFill>;
};
export const BlumenpyramideV3:React.FC=()=>{
 const [handle]=useState(()=>delayRender('Loading campaign fonts'));
 useEffect(()=>{Promise.all([document.fonts.load('200px Anton'),document.fonts.load('40px Quiet'),document.fonts.load('90px Atelier')]).then(()=>continueRender(handle));},[handle]);
 return <AbsoluteFill style={{background:C.black,overflow:'hidden'}}><style>{FONT}</style><TransitionSeries>
  {shots.map((s,i)=><React.Fragment key={i}>
   <TransitionSeries.Sequence durationInFrames={at(s.end)-at(s.start)+(i<shots.length-1?transFrames(i):0)}><ShotScene shot={s} index={i}/></TransitionSeries.Sequence>
   {i<shots.length-1&&(s.transition==='warp'?<TransitionSeries.Transition timing={linearTiming({durationInFrames:transFrames(i),easing:Easing.inOut(Easing.cubic)})} presentation={crosswarp({})}/>:s.transition==='zoom'?<TransitionSeries.Transition timing={linearTiming({durationInFrames:transFrames(i),easing:Easing.inOut(Easing.cubic)})} presentation={crossZoom({strength:.25})}/>:s.transition==='burn'?<TransitionSeries.Transition timing={linearTiming({durationInFrames:transFrames(i),easing:Easing.inOut(Easing.cubic)})} presentation={crosswarp({})}/>:<TransitionSeries.Transition timing={linearTiming({durationInFrames:transFrames(i),easing:Easing.inOut(Easing.cubic)})} presentation={blurSlide({direction:i%2?'from-right':'from-left',blur:12})}/>)}
  </React.Fragment>)}
 </TransitionSeries><Audio src={staticFile('assets/bloom-afterdark-140.wav')} volume={.9}/></AbsoluteFill>;
};
const Root=()=> <Composition id="BlumenpyramideV3" component={BlumenpyramideV3} width={1080} height={1920} fps={60} durationInFrames={1800}/>;
registerRoot(Root);
