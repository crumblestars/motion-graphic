from pathlib import Path
import json,subprocess,hashlib
files=['deliverables/Blumenpyramide-V3-Film-HD.mp4','deliverables/Blumenpyramide-V3-Film-leger.mp4']
out={}
for file in files:
 p=Path(file);meta=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration,size:stream=codec_name,width,height,r_frame_rate,nb_frames,sample_rate,channels','-of','json',str(p)]))
 assert abs(float(meta['format']['duration'])-30)<.03
 v=next(s for s in meta['streams'] if s['codec_name']=='h264');assert v['nb_frames']=='1800' and v['r_frame_rate']=='60/1' and (v['width'],v['height'])==(720,1280)
 a=next(s for s in meta['streams'] if s['codec_name']=='aac');assert a['channels']==2
 subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-xerror','-i',str(p),'-f','null','-'],check=True)
 out[file]={'metadata':meta,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'full_decode':'passed'}
Path('deliverables/VALIDATION.json').write_text(json.dumps(out,indent=2));print('Both video files decode cleanly and contain 1800 frames / 60fps.')
