from pathlib import Path
import subprocess,json,zipfile,hashlib
from PIL import Image,ImageDraw,ImageFont
root=Path.cwd();out=root/'deliverables';master=out/'Blumenpyramide-V3-Film-HD.mp4';light=out/'Blumenpyramide-V3-Film-leger.mp4'
subprocess.run(['ffmpeg','-y','-hide_banner','-loglevel','error','-i',str(master),'-c:v','libx264','-preset','fast','-crf','25','-maxrate','2300k','-bufsize','4600k','-threads','2','-pix_fmt','yuv420p','-c:a','aac','-b:a','128k','-movflags','+faststart',str(light)],check=True)
subprocess.run(['python','research/validate-delivery.py'],check=True)
beats=[(0,4),(4,6),(6,10),(10,14),(14,16),(16,20),(20,22),(22,24),(24,28),(28,32),(32,36),(36,38),(38,42),(42,44),(44,48),(48,52),(52,56),(56,60),(60,63),(63,70)]
board=Image.new('RGB',(1080,1664),'#090806');draw=ImageDraw.Draw(board);font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',15)
frames=out/'qa-frames';frames.mkdir(exist_ok=True)
for i,(a,b) in enumerate(beats):
 t=(a+b)/2*60/140
 path=frames/f'{i+1:02}.jpg'
 subprocess.run(['ffmpeg','-y','-hide_banner','-loglevel','error','-ss',str(t),'-i',str(master),'-frames:v','1','-vf','scale=216:384','-q:v','2',str(path)],check=True)
 im=Image.open(path);x=(i%5)*216;y=(i//5)*416;board.paste(im,(x,y));draw.text((x+9,y+392),f'{i+1:02} / {a*60/140:04.1f}–{b*60/140:04.1f}s',fill='#f8efd9',font=font)
board.save(out/'Storyboard-V3.jpg',quality=92)
subprocess.run(['ffmpeg','-y','-hide_banner','-loglevel','error','-ss','28.8','-i',str(master),'-frames:v','1','-q:v','2',str(out/'Affiche-V3.jpg')],check=True)
print('Light export, full decoding, storyboard and poster completed.')
