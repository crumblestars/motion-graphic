from pathlib import Path
import zipfile,hashlib,json
root=Path.cwd();target=root/'deliverables/Blumenpyramide-V3-Sources.zip'
paths=[root/n for n in ['package.json','package-lock.json','tsconfig.json','DESIGN.md','README-FR.md','MEDIA-CREDITS.md','index.html']]
for folder in ['src','public','licenses']:
 paths.extend(p for p in (root/folder).rglob('*') if p.is_file())
for name in ['prepare-footage.py','music-v3.py','render-v3.mjs','post-render.py','validate-delivery.py','package-sources.py','footage-map.json','provenance.json','tesseract-readability.json','blooming-data-original-credits.html']:
 paths.append(root/'research'/name)
for name in ['Blumenpyramide-V3-Film-HD.mp4','VALIDATION.json','Storyboard-V3.jpg','Affiche-V3.jpg','hyperframes-check.json','browser-errors.json']:
 p=root/'deliverables'/name
 if p.exists():paths.append(p)
with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in paths:
  z.write(p,Path('Blumenpyramide-V3')/p.relative_to(root))
with zipfile.ZipFile(target) as z:
 assert z.testzip() is None
print('Source archive:',target.stat().st_size,'bytes;',len(paths),'files')
