from pathlib import Path
import subprocess, concurrent.futures,json
source='assets/flowers-blooming-candidate.mp4'
shots=[('amber',5.2,18.0,650,345),('peach',52,68.2,665,345),('gold',69.3,84.5,620,370),('pink',85.3,101.8,650,300),('red',102.7,121.3,570,340),('garden',140,159.5,630,360),('golden',160.2,175.5,735,390)]
def make(s):
 name,a,b,cx,cy=s;dur=b-a;size=700;left=max(0,min(1280-size,cx-size/2));top=max(0,min(720-size,cy-size/2))
 # Fast-in / slow middle / fast-out time remapping of genuine flower opening footage.
 vf=f"crop={size}:{size}:{int(left)}:{int(top)},setpts=3.6*(0.5-0.5*cos(PI*(PTS-STARTPTS)*TB/{dur}))/TB,fps=60,scale=1080:1080:flags=lanczos,eq=contrast=1.07:saturation=0.86:brightness=-0.012,colorbalance=rs=0.035:bs=-0.025,format=rgb24,lutrgb=r='max(val,9)':g='max(val,8)':b='max(val,6)',format=yuv420p,setsar=1"
 out=f'public/assets/bloom-{name}.mp4'
 subprocess.run(['ffmpeg','-y','-hide_banner','-loglevel','error','-ss',str(a),'-t',str(dur),'-i',source,'-vf',vf,'-an','-c:v','libx264','-preset','fast','-crf','19','-threads','2','-pix_fmt','yuv420p','-movflags','+faststart',out],check=True)
 meta=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','json',out]));assert float(meta['format']['duration'])>3.3
 return {'name':name,'source_start':a,'source_end':b,'file':out,'retime':'sine-eased variable time map; 3.6 seconds'}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as e:r=list(e.map(make,shots))
Path('research/footage-map.json').write_text(json.dumps(r,indent=2));print('Prepared',len(r),'real time-lapse clips.')
