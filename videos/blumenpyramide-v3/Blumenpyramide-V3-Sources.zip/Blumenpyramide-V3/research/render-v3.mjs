import {resolve} from 'node:path';
import {bundle} from '@remotion/bundler';
import {selectComposition,renderStill,renderMedia,openBrowser} from '@remotion/renderer';
import {writeFileSync} from 'node:fs';
const serveUrl=await bundle({entryPoint:resolve('src/index.tsx'),publicDir:resolve('public'),outDir:resolve('build'),onProgress:()=>{}});
const browser=await openBrowser('chrome',{browserExecutable:'/usr/bin/chromium',chromiumOptions:{gl:'swangle'}});
const composition=await selectComposition({serveUrl,id:'BlumenpyramideV3',puppeteerInstance:browser});
console.log('Composition',composition.width,composition.height,composition.durationInFrames);
const patch=process.argv.includes('--legibility-patch');
let lastBucket=-1;const logs=[];
const log=({type,text})=>{if(type==='error')logs.push(text)};
if(process.argv.includes('--stills')){
 for(const [name,frame] of [['hook',50],['type',120],['bloom',205],['split',310],['date',745],['mask',1280],['gallery',1385],['final',1730],['transition',108]]){
  await renderStill({serveUrl,composition,frame,output:`deliverables/${name}.jpg`,imageFormat:'jpeg',scale:.5,puppeteerInstance:browser,browserExecutable:'/usr/bin/chromium',chromiumOptions:{gl:'swangle'},onBrowserLog:log});console.log('Still',name,frame);
 }
 writeFileSync('deliverables/browser-errors.json',JSON.stringify(logs));
}else{
 await renderMedia({serveUrl,composition,codec:'h264',outputLocation:patch?'deliverables/V3-legibility-patch.mp4':'deliverables/Blumenpyramide-V3-Film-HD.mp4',frameRange:patch?[1440,1556]:undefined,crf:18,scale:2/3,concurrency:2,puppeteerInstance:browser,browserExecutable:'/usr/bin/chromium',chromiumOptions:{gl:'swangle'},onBrowserLog:log,onProgress:p=>{const bucket=Math.floor(p.progress*100);if(bucket!==lastBucket){lastBucket=bucket;console.log('Progress',bucket+'%',p.renderedFrames,'/',p.encodedFrames);writeFileSync('deliverables/render-progress.json',JSON.stringify({progress:p.progress,rendered:p.renderedFrames,encoded:p.encodedFrames}))}}});
 writeFileSync('deliverables/browser-errors.json',JSON.stringify(logs));console.log('Rendered V3');
}
await browser.close({silent:true});
